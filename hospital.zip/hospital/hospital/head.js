// head.js - Fixed version

// DOM Elements with error handling
const statusBadges = document.querySelectorAll('.status-badge');
const resourceCounts = document.querySelectorAll('.resource-count');
const loginBtn = document.getElementById('login-btn');
const heroBadge = document.querySelector('.hero-badge');

// Configuration for Simulation
const SIMULATION_INTERVAL = 3000; // 3 seconds

// 1. Simulated Live Updates Service
function startLiveSimulation() {
    setInterval(() => {
        // Randomly update a few resource counts to simulate activity
        if (resourceCounts.length > 0) {
            const randomIndex = Math.floor(Math.random() * resourceCounts.length);
            const element = resourceCounts[randomIndex];

            // Only update if it's a number (avoid updating times like "10:30 AM")
            const currentText = element.innerText;
            const currentValue = parseInt(currentText);

            if (!isNaN(currentValue)) {
                const change = Math.floor(Math.random() * 3) - 1; // -1, 0, or 1
                let newValue = currentValue + change;
                if (newValue < 0) newValue = 0;

                // Update Text
                element.innerText = `${newValue} Available`;

                // Visual Flash Effect for Update
                element.style.color = "#007bff";
                setTimeout(() => {
                    element.style.color = ""; // Reset to CSS class color
                }, 500);
            }
        }
    }, SIMULATION_INTERVAL);
}

// 2. Global Button Click Handler & Login State Management
document.body.addEventListener('click', function (e) {
    // Check if Logout Button was clicked
    if (e.target.closest('#login-btn') && localStorage.getItem('isLoggedIn') === 'true') {
        e.preventDefault();
        if (confirm("Are you sure you want to logout?")) {
            localStorage.removeItem('isLoggedIn');
            localStorage.removeItem('hospitalName');
            localStorage.removeItem('nhm_current_user');
            window.location.reload();
        }
        return;
    }

    // Handle login button for non-logged users
    if (e.target.closest('#login-btn') && localStorage.getItem('isLoggedIn') !== 'true') {
        // Let default href work (go to login.html)
        return;
    }

    // Default Redirect for other buttons (Simulating restricted access)
    if (e.target.closest('button') || (e.target.tagName === 'A' && e.target.classList.contains('btn'))) {
        if (localStorage.getItem('isLoggedIn') !== 'true') {
            e.preventDefault();
            window.location.href = 'login.html';
        } else {
            // Logged in user clicking buttons
            if (e.target.getAttribute('href') === 'login.html') {
                e.preventDefault();
                alert("You are already logged in.");
            }
        }
    }
});

// 3. UI Initialization based on Login State
function updateUIForLoginState() {
    const loginBtn = document.getElementById('login-btn');
    const bookNavBtn = document.getElementById('book-nav-btn');

    if (localStorage.getItem('isLoggedIn') === 'true') {
        const hospitalName = localStorage.getItem('hospitalName') || 'Hospital Admin';

        if (loginBtn) {
            loginBtn.innerHTML = '<i class="fa-solid fa-right-from-bracket"></i> Logout';
            loginBtn.classList.remove('btn-outline');
            loginBtn.classList.add('btn-danger');
            loginBtn.setAttribute('title', `Logged in as ${hospitalName}`);
            loginBtn.href = "#";
        }

        if (bookNavBtn) {
            bookNavBtn.innerHTML = '<i class="fa-solid fa-gauge-high"></i> Dashboard';
            bookNavBtn.href = "hospital_dashboard.html";
        }

        // Update Hero Badge
        if (heroBadge) {
            heroBadge.innerHTML = `Welcome, ${hospitalName} <span class="pulse"></span>`;
        }
    } else {
        if (loginBtn) {
            loginBtn.innerHTML = 'Login';
            loginBtn.classList.remove('btn-danger');
            loginBtn.classList.add('btn-outline');
            loginBtn.href = "login.html";
        }

        if (bookNavBtn) {
            bookNavBtn.innerHTML = 'Book Now';
            bookNavBtn.href = "login.html";
        }
    }
}

// Initialize
document.addEventListener('DOMContentLoaded', () => {
    startLiveSimulation();
    updateUIForLoginState();
    console.log("NHM Hospital Monitor: System Ready");
});