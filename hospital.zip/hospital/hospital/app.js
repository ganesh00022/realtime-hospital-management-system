// app.js - Updated with working hospital switcher

// --- STATE MANAGEMENT ---
const defaultState = {
    doctors: [
        { id: 'd1', name: 'Dr. Sarah Jenkins', dept: 'Cardiology', maxSlots: 5, specs: 'Heart Specialist', status: 'Available' },
        { id: 'd2', name: 'Dr. Ramesh Kumar', dept: 'Orthopedics', maxSlots: 4, specs: 'Bone & Joint', status: 'Available' },
        { id: 'd3', name: 'Dr. Emily Chen', dept: 'Pediatrics', maxSlots: 6, specs: 'Child Care', status: 'Available' },
        { id: 'd4', name: 'Dr. Michael Chang', dept: 'Neurology', maxSlots: 3, specs: 'Brain & Nerves', status: 'Available' }
    ],
    wards: [
        { id: 'w1', name: 'General Ward A', type: 'general', capacity: 40, occupied: 0 },
        { id: 'w2', name: 'General Ward B', type: 'general', capacity: 40, occupied: 0 },
        { id: 'w3', name: 'Intensive Care Unit (ICU)', type: 'icu', capacity: 20, occupied: 0 },
        { id: 'w4', name: 'Emergency', type: 'emergency', capacity: 15, occupied: 0 },
        { id: 'w5', name: 'Maternity Ward', type: 'maternity', capacity: 25, occupied: 0 },
        { id: 'w6', name: 'Pediatric ICU', type: 'icu', capacity: 10, occupied: 0 },
        { id: 'w7', name: 'Cardiac ICU', type: 'icu', capacity: 8, occupied: 0 },
        { id: 'w8', name: 'Trauma Emergency', type: 'emergency', capacity: 12, occupied: 0 }
    ],
    appointments: [],
    bookedSlots: {},
    users: [
        { id: 'admin', name: 'System Administrator', pass: 'admin', role: 'admin' }
    ]
};

const CITY_HOSPITAL_MAP = {
    "Mumbai": [
        { id: "HOSP-MUM-01", name: "Tata Memorial Centre" },
        { id: "HOSP-MUM-02", name: "Kokilaben Dhirubhai Ambani Hospital" },
        { id: "HOSP-MUM-03", name: "Lilavati Hospital and Research Centre" },
        { id: "HOSP-MUM-04", name: "Jaslok Hospital and Research Centre" },
        { id: "HOSP-MUM-05", name: "HN Reliance Foundation Hospital" }
    ],
    "Navi Mumbai": [
        { id: "HOSP-MUM-06", name: "Fortis Hospital" }
    ]
};

// State Variables
const urlParams = new URLSearchParams(window.location.search);
let currentHospId = urlParams.get('id') || localStorage.getItem('nhm_selected_hosp_id') || 'HOSP-MUM-01';
let selectedHospitalId = 'all'; // For admin dashboard - which hospital to view
let hospitalState = JSON.parse(localStorage.getItem(`nhm_state_${currentHospId}`)) || JSON.parse(JSON.stringify(defaultState));
let currentUser = JSON.parse(localStorage.getItem('nhm_current_user')) || null;

function saveState() {
    localStorage.setItem(`nhm_state_${currentHospId}`, JSON.stringify(hospitalState));
    localStorage.setItem('nhm_state', JSON.stringify(hospitalState));
}

const TIME_SLOTS_MASTER = [
    "09:00 AM", "09:30 AM", "10:00 AM", "10:30 AM",
    "11:00 AM", "11:30 AM", "02:00 PM", "02:30 PM",
    "03:00 PM", "03:30 PM", "04:00 PM", "04:30 PM"
];

// --- INITIALIZATION ---
document.addEventListener('DOMContentLoaded', () => {
    runMigrationCleanup();
    setupAuth();
    if (currentUser) {
        initializeApp();
    } else {
        showAuth();
    }
});

function runMigrationCleanup() {
    if (!localStorage.getItem('nhm_slate_cleaned_v3')) {
        const legacyMap = {
            'hosp1': 'HOSP-MUM-01',
            'hosp2': 'HOSP-MUM-02',
            'hosp3': 'HOSP-MUM-03',
            'hosp4': 'HOSP-MUM-04',
            'hosp5': 'HOSP-MUM-05',
            'hosp6': 'HOSP-MUM-06'
        };

        for (const [oldId, newId] of Object.entries(legacyMap)) {
            const oldKey = `nhm_state_${oldId}`;
            const newKey = `nhm_state_${newId}`;

            let data = JSON.parse(localStorage.getItem(oldKey)) || JSON.parse(localStorage.getItem('nhm_state'));
            if (data && data.wards) {
                data.wards.forEach(w => w.occupied = 0);
                localStorage.setItem(newKey, JSON.stringify(data));
            }
        }

        localStorage.setItem('nhm_slate_cleaned_v3', 'true');
        console.log('NHM: All hospital IDs normalized and occupancy reset.');
    }
}

// --- AUTHENTICATION ---
function setupAuth() {
    const views = ['login-view', 'register-view', 'location-view'];
    const showView = (id) => {
        views.forEach(v => {
            const el = document.getElementById(v);
            if (el) el.classList.add('hidden');
        });
        const target = document.getElementById(id);
        if (target) target.classList.remove('hidden');
    };

    const bindClick = (id, handler) => {
        const el = document.getElementById(id);
        if (el) el.addEventListener('click', handler);
    };

    bindClick('link-register', (e) => { e.preventDefault(); showView('register-view'); });
    bindClick('link-login', (e) => { e.preventDefault(); showView('login-view'); });

    // Patient Login
    const loginForm = document.getElementById('login-form');
    if (loginForm) {
        loginForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            const id = document.getElementById('login-id')?.value.trim();
            if (id) {
                const user = { id: id, name: 'Patient ' + id, role: 'patient' };
                currentUser = user;
                localStorage.setItem('nhm_current_user', JSON.stringify(user));
                localStorage.setItem('isLoggedIn', 'true');
                localStorage.setItem('hospitalName', user.name);

                showToast('Login Successful', `Welcome, ${user.name}`);
                loginForm.reset();

                if (!localStorage.getItem('nhm_selected_hosp_id')) {
                    showLocationSelector();
                } else {
                    initializeApp();
                }
            }
        });
    }

    // Register Form
    const registerForm = document.getElementById('register-form');
    if (registerForm) {
        registerForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const name = document.getElementById('reg-name')?.value;
            const id = document.getElementById('reg-id')?.value;
            if (name && id) {
                const user = { id: id, name: name, role: 'patient' };
                currentUser = user;
                localStorage.setItem('nhm_current_user', JSON.stringify(user));
                localStorage.setItem('isLoggedIn', 'true');
                showToast('Registration Successful', 'Please select your hospital');
                showLocationSelector();
            }
        });
    }

    // Logout button
    const logoutBtn = document.getElementById('btn-logout');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', () => {
            currentUser = null;
            localStorage.removeItem('nhm_current_user');
            localStorage.removeItem('isLoggedIn');
            localStorage.removeItem('hospitalName');
            window.location.href = 'head.html';
        });
    }
}

// --- HELPER FUNCTIONS ---
function showAuth() {
    const wrapper = document.getElementById('auth-wrapper');
    const shell = document.getElementById('app-shell');
    if (wrapper) wrapper.classList.remove('hidden');
    if (shell) shell.classList.add('hidden');
}

function showLocationSelector() {
    const wrapper = document.getElementById('auth-wrapper');
    if (wrapper) {
        document.querySelectorAll('#auth-wrapper .auth-box').forEach(el => el.classList.add('hidden'));
        const locView = document.getElementById('location-view');
        if (locView) locView.classList.remove('hidden');
    }

    const citySelect = document.getElementById('city-select');
    const hospSelect = document.getElementById('hosp-select');
    const locForm = document.getElementById('location-form');

    if (citySelect) {
        citySelect.addEventListener('change', () => {
            const city = citySelect.value;
            hospSelect.innerHTML = '<option value="" disabled selected>Choose a hospital</option>';
            if (CITY_HOSPITAL_MAP[city]) {
                CITY_HOSPITAL_MAP[city].forEach(h => {
                    const opt = document.createElement('option');
                    opt.value = h.id;
                    opt.textContent = h.name;
                    hospSelect.appendChild(opt);
                });
                hospSelect.disabled = false;
            } else {
                hospSelect.disabled = true;
            }
        });
    }

    if (locForm) {
        locForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const selectedHospId = hospSelect?.value;
            if (selectedHospId) {
                localStorage.setItem('nhm_selected_hosp_id', selectedHospId);
                currentHospId = selectedHospId;
                hospitalState = JSON.parse(localStorage.getItem(`nhm_state_${currentHospId}`)) || JSON.parse(JSON.stringify(defaultState));
                initializeApp();
            }
        });
    }

    const btnBack = document.getElementById('link-logout-back');
    if (btnBack) {
        btnBack.addEventListener('click', (e) => {
            e.preventDefault();
            localStorage.removeItem('nhm_current_user');
            location.reload();
        });
    }
}

function initializeApp() {
    const wrapper = document.getElementById('auth-wrapper');
    if (wrapper) wrapper.classList.add('hidden');
    const shell = document.getElementById('app-shell');
    if (shell) shell.classList.remove('hidden');

    const userNameEl = document.getElementById('current-user-name');
    const userRoleEl = document.getElementById('current-user-role');
    const userAvatar = document.getElementById('user-avatar');

    if (userNameEl) userNameEl.textContent = currentUser?.name || 'User';
    if (userRoleEl) userRoleEl.textContent = currentUser?.role === 'admin' ? 'Administrator' : 'Patient';
    if (userAvatar) userAvatar.src = `https://ui-avatars.com/api/?name=${encodeURIComponent(currentUser?.name || 'User')}&background=0D8ABC&color=fff`;

    // Role Based UI
    const navAdmin = document.querySelector('.nav-item[data-view="admin"]');
    const navBooking = document.querySelector('.nav-item[data-view="booking"]');

    if (currentUser?.role === 'patient') {
        if (navAdmin) navAdmin.style.display = 'none';
        if (navBooking) navBooking.style.display = 'flex';
        const pName = document.getElementById('patient-name');
        if (pName) {
            pName.value = currentUser.name;
            pName.readOnly = true;
        }
    } else {
        if (navAdmin) navAdmin.style.display = 'flex';
    }

    setupNavigation();

    // Check if we're in admin dashboard
    if (window.location.pathname.includes('admin_dashboard')) {
        setupHospitalSwitcher();
        updateAllHospitalsStats();
    } else {
        updateDashboardStats();
        populateForms();
        renderWardsGrid('all');
        setupBookingForm();
        setupAdminControls();
        setupWardFilters();
    }

    // Hospital name display
    const hospNameDisplay = document.getElementById('current-hosp-name-title');
    if (hospNameDisplay) {
        hospNameDisplay.textContent = getHospitalName(currentHospId);
    }

    // Default to dashboard
    const dashNav = document.querySelector('.nav-item[data-view="dashboard"]');
    if (dashNav) dashNav.click();

    const btnChangeLoc = document.getElementById('nav-change-hosp');
    if (btnChangeLoc) {
        btnChangeLoc.addEventListener('click', () => {
            const shell = document.getElementById('app-shell');
            if (shell) shell.classList.add('hidden');
            showLocationSelector();
        });
    }

    // Real-time updates
    setInterval(fetchWards, 2000);
}

async function fetchWards() {
    try {
        // For admin dashboard, update all hospitals view
        if (window.location.pathname.includes('admin_dashboard')) {
            updateAllHospitalsStats();
            const bedsSection = document.getElementById('beds');
            if (bedsSection && !bedsSection.classList.contains('hidden')) {
                renderMultiHospitalWards();
            }
        } else {
            const savedData = localStorage.getItem(`nhm_state_${currentHospId}`);
            if (savedData) {
                const newState = JSON.parse(savedData);
                hospitalState.wards = newState.wards;
                hospitalState.doctors = newState.doctors;
                hospitalState.appointments = newState.appointments;
                hospitalState.bookedSlots = newState.bookedSlots;

                updateDashboardStats();
                updateAdminLists();

                const bedsSection = document.getElementById('beds');
                if (bedsSection && !bedsSection.classList.contains('hidden')) {
                    const activeFilter = document.querySelector('.filter-btn.active')?.getAttribute('data-ward') || 'all';
                    renderWardsGrid(activeFilter);
                }
            }
        }
    } catch (err) {
        console.error('Local real-time sync failed', err);
    }
}

function setupNavigation() {
    const navItems = document.querySelectorAll('.nav-item');
    const views = document.querySelectorAll('.view');

    navItems.forEach(item => {
        item.addEventListener('click', (e) => {
            const targetView = item.getAttribute('data-view');
            if (!targetView) return;

            navItems.forEach(nav => nav.classList.remove('active'));
            item.classList.add('active');

            views.forEach(view => {
                view.classList.remove('active');
                view.classList.add('hidden');
            });
            const targetEl = document.getElementById(targetView);
            if (targetEl) {
                targetEl.classList.remove('hidden');
                targetEl.classList.add('active');
            }

            if (targetView === 'dashboard') {
                if (window.location.pathname.includes('admin_dashboard')) {
                    updateAllHospitalsStats();
                } else {
                    updateDashboardStats();
                }
            }
            if (targetView === 'beds') {
                if (window.location.pathname.includes('admin_dashboard')) {
                    renderMultiHospitalWards();
                } else {
                    const activeFilter = document.querySelector('.filter-btn.active')?.getAttribute('data-ward') || 'all';
                    renderWardsGrid(activeFilter);
                }
            }
            if (targetView === 'admin') updateAdminLists();
            if (targetView === 'hospitals') renderHospitalAssignments();
        });
    });
}

// --- HOSPITAL SWITCHER FOR ADMIN DASHBOARD ---
function setupHospitalSwitcher() {
    const grid = document.getElementById('hospital-switcher-grid');
    if (!grid) return;

    // Get all hospitals
    const hospitalIds = getAllHospitalIds();

    // Clear grid
    grid.innerHTML = '';

    // Add "All Hospitals" button
    const allBtn = document.createElement('button');
    allBtn.className = 'hosp-btn' + (selectedHospitalId === 'all' ? ' active' : '');
    allBtn.setAttribute('data-hosp', 'all');
    allBtn.innerHTML = '<i class="fa-solid fa-building-columns"></i><span>All Hospitals</span>';
    allBtn.addEventListener('click', () => {
        document.querySelectorAll('.hosp-btn').forEach(btn => btn.classList.remove('active'));
        allBtn.classList.add('active');
        selectedHospitalId = 'all';

        // Update display
        const badge = document.getElementById('selected-hospital-name');
        if (badge) badge.textContent = 'All Hospitals';

        // Refresh dashboard with all hospitals data
        updateAllHospitalsStats();

        // If beds view is active, refresh it
        if (document.getElementById('beds').classList.contains('active')) {
            renderMultiHospitalWards();
        }

        showToast('View Changed', 'Showing all hospitals');
    });
    grid.appendChild(allBtn);

    // Add each hospital button
    hospitalIds.forEach(id => {
        if (id === 'all') return;

        const hospName = getHospitalName(id);
        const btn = document.createElement('button');
        btn.className = 'hosp-btn' + (selectedHospitalId === id ? ' active' : '');
        btn.setAttribute('data-hosp', id);
        btn.innerHTML = `<i class="fa-solid fa-hospital"></i><span>${hospName.substring(0, 15)}${hospName.length > 15 ? '...' : ''}</span>`;
        btn.addEventListener('click', () => {
            document.querySelectorAll('.hosp-btn').forEach(btn => btn.classList.remove('active'));
            btn.classList.add('active');
            selectedHospitalId = id;

            // Update display
            const badge = document.getElementById('selected-hospital-name');
            if (badge) badge.textContent = hospName;

            // Switch to this hospital's data
            switchToHospital(id);

            showToast('Hospital Selected', `Viewing ${hospName}`);
        });
        grid.appendChild(btn);
    });

    // Also setup hospital filter for beds view
    const filterSelect = document.getElementById('bed-hospital-filter');
    if (filterSelect) {
        filterSelect.innerHTML = '<option value="all">All Hospitals</option>';
        hospitalIds.forEach(id => {
            if (id === 'all') return;
            const hospName = getHospitalName(id);
            const opt = document.createElement('option');
            opt.value = id;
            opt.textContent = hospName;
            filterSelect.appendChild(opt);
        });

        filterSelect.addEventListener('change', (e) => {
            const hospId = e.target.value;
            if (hospId === 'all') {
                renderMultiHospitalWards();
            } else {
                renderSingleHospitalWards(hospId);
            }
        });
    }
}

function switchToHospital(hospId) {
    // Load hospital data
    const key = `nhm_state_${hospId}`;
    const data = JSON.parse(localStorage.getItem(key)) || generateDummyData(hospId);

    // Update display
    updateDashboardStatsForHospital(data);

    // Update recent bookings for this hospital
    updateRecentBookingsForHospital(data, getHospitalName(hospId));
}

function updateDashboardStatsForHospital(data) {
    if (!data) return;

    const totalDoctors = data.doctors.length;

    let totalBeds = 0;
    let occupiedBeds = 0;
    let icuAvailable = 0;

    data.wards.forEach(w => {
        totalBeds += w.capacity;
        occupiedBeds += w.occupied;
        if (w.type === 'icu' || w.type === 'emergency') {
            icuAvailable += (w.capacity - w.occupied);
        }
    });

    const availableBeds = totalBeds - occupiedBeds;
    const activeAppointments = data.appointments.filter(a => a.status === 'Confirmed').length;

    document.getElementById('stat-doctors') && (document.getElementById('stat-doctors').textContent = totalDoctors);
    document.getElementById('stat-beds') && (document.getElementById('stat-beds').textContent = availableBeds);
    document.getElementById('stat-appointments') && (document.getElementById('stat-appointments').textContent = activeAppointments);
    document.getElementById('stat-icu') && (document.getElementById('stat-icu').textContent = `${icuAvailable} Available`);

    // Render Occupancy Bars for this hospital
    const occupancyContainer = document.getElementById('occupancy-summary');
    if (occupancyContainer) {
        occupancyContainer.innerHTML = '';

        data.wards.forEach(w => {
            const pct = w.capacity > 0 ? Math.round((w.occupied / w.capacity) * 100) : 0;
            const div = document.createElement('div');
            div.className = 'progress-group';
            div.innerHTML = `
                <div class="progress-label">
                    <span>${w.name}</span>
                    <span>${w.occupied} / ${w.capacity} (${pct}%)</span>
                </div>
                <div class="progress-bar-container">
                    <div class="progress-bar ${w.type}" style="width: ${pct}%"></div>
                </div>
            `;
            occupancyContainer.appendChild(div);
        });
    }
}

function updateRecentBookingsForHospital(data, hospName) {
    const recentList = document.getElementById('recent-bookings-list');
    if (!recentList) return;

    recentList.innerHTML = '';
    const recentApts = [...data.appointments].reverse().slice(0, 5);

    if (recentApts.length === 0) {
        recentList.innerHTML = '<li class="booking-item" style="justify-content: center;">No recent appointments</li>';
        return;
    }

    recentApts.forEach(apt => {
        const doc = data.doctors.find(d => d.id === apt.doctorId);
        const li = document.createElement('li');
        li.className = 'booking-item';

        let statusClass = apt.status === 'Confirmed' ? 'status-confirmed' : 'status-cancelled';

        li.innerHTML = `
            <div class="booking-info">
                <h4>${apt.patientName} <span style="font-size:0.7rem; color:var(--text-muted)">@ ${hospName}</span></h4>
                <p>${apt.slotTime} with ${doc ? doc.name : 'Unknown'}</p>
            </div>
            <div class="booking-status ${statusClass}">${apt.status}</div>
        `;
        recentList.appendChild(li);
    });
}

function updateAllHospitalsStats() {
    const hospitalIds = getAllHospitalIds();

    let totalDoctors = 0;
    let totalBeds = 0;
    let totalOccupied = 0;
    let totalAppointments = 0;
    let totalIcuAvailable = 0;

    hospitalIds.forEach(id => {
        const key = `nhm_state_${id}`;
        const data = JSON.parse(localStorage.getItem(key)) || defaultState;

        totalDoctors += data.doctors.length;

        data.wards.forEach(w => {
            totalBeds += w.capacity;
            totalOccupied += w.occupied;
            if (w.type === 'icu' || w.type === 'emergency') {
                totalIcuAvailable += (w.capacity - w.occupied);
            }
        });

        totalAppointments += data.appointments.filter(a => a.status === 'Confirmed').length;
    });

    const availableBeds = totalBeds - totalOccupied;

    document.getElementById('stat-doctors') && (document.getElementById('stat-doctors').textContent = totalDoctors);
    document.getElementById('stat-beds') && (document.getElementById('stat-beds').textContent = availableBeds);
    document.getElementById('stat-appointments') && (document.getElementById('stat-appointments').textContent = totalAppointments);
    document.getElementById('stat-icu') && (document.getElementById('stat-icu').textContent = `${totalIcuAvailable} Available`);

    // Aggregate occupancy for all hospitals
    const occupancyContainer = document.getElementById('occupancy-summary');
    if (occupancyContainer) {
        occupancyContainer.innerHTML = '';

        // Show top 5 wards across all hospitals
        let allWards = [];
        hospitalIds.forEach(id => {
            const key = `nhm_state_${id}`;
            const data = JSON.parse(localStorage.getItem(key)) || defaultState;
            const hospName = getHospitalName(id);

            data.wards.forEach(w => {
                allWards.push({
                    ...w,
                    hospitalName: hospName
                });
            });
        });

        // Show first 8 wards to avoid clutter
        allWards.slice(0, 8).forEach(w => {
            const pct = w.capacity > 0 ? Math.round((w.occupied / w.capacity) * 100) : 0;
            const div = document.createElement('div');
            div.className = 'progress-group';
            div.innerHTML = `
                <div class="progress-label">
                    <span>${w.hospitalName} - ${w.name}</span>
                    <span>${w.occupied} / ${w.capacity} (${pct}%)</span>
                </div>
                <div class="progress-bar-container">
                    <div class="progress-bar ${w.type}" style="width: ${pct}%"></div>
                </div>
            `;
            occupancyContainer.appendChild(div);
        });
    }

    // Recent bookings across all hospitals
    updateAllRecentBookings();
}

function updateAllRecentBookings() {
    const recentList = document.getElementById('recent-bookings-list');
    if (!recentList) return;

    recentList.innerHTML = '';

    const hospitalIds = getAllHospitalIds();
    let allApts = [];

    hospitalIds.forEach(id => {
        const key = `nhm_state_${id}`;
        const data = JSON.parse(localStorage.getItem(key)) || defaultState;
        const hospName = getHospitalName(id);

        data.appointments.forEach(apt => {
            const doc = data.doctors.find(d => d.id === apt.doctorId);
            allApts.push({
                ...apt,
                hospitalName: hospName,
                doctorName: doc ? doc.name : 'Unknown'
            });
        });
    });

    // Sort by date (most recent first) and take last 5
    allApts.sort((a, b) => (b.id || '').localeCompare(a.id || ''));
    const recentApts = allApts.slice(0, 5);

    if (recentApts.length === 0) {
        recentList.innerHTML = '<li class="booking-item" style="justify-content: center;">No recent appointments</li>';
        return;
    }

    recentApts.forEach(apt => {
        const li = document.createElement('li');
        li.className = 'booking-item';

        let statusClass = apt.status === 'Confirmed' ? 'status-confirmed' : 'status-cancelled';

        li.innerHTML = `
            <div class="booking-info">
                <h4>${apt.patientName} <span style="font-size:0.7rem; color:var(--text-muted)">@ ${apt.hospitalName}</span></h4>
                <p>${apt.slotTime} with ${apt.doctorName}</p>
            </div>
            <div class="booking-status ${statusClass}">${apt.status}</div>
        `;
        recentList.appendChild(li);
    });
}

// --- REST OF THE FUNCTIONS (keep existing ones) ---

function getHospitalName(hid) {
    for (const city in CITY_HOSPITAL_MAP) {
        const h = CITY_HOSPITAL_MAP[city].find(x => x.id === hid);
        if (h) return h.name;
    }
    const dynamicHospitals = JSON.parse(localStorage.getItem('nhm_dynamic_hospitals')) || [];
    const dynamic = dynamicHospitals.find(h => h.id === hid);
    if (dynamic) return dynamic.name;
    return hid;
}

function getAllHospitalIds() {
    const baseIds = ['HOSP-MUM-01', 'HOSP-MUM-02', 'HOSP-MUM-03', 'HOSP-MUM-04', 'HOSP-MUM-05', 'HOSP-MUM-06'];
    const dynamicHospitals = JSON.parse(localStorage.getItem('nhm_dynamic_hospitals')) || [];
    return [...baseIds, ...dynamicHospitals.map(h => h.id)];
}

function generateDummyData(hospId) {
    // Clone default
    const newData = JSON.parse(JSON.stringify(defaultState));

    // Randomize slightly so they look different
    newData.wards.forEach(w => {
        w.capacity = Math.floor(w.capacity * (0.8 + Math.random() * 0.4));
        w.occupied = 0;
    });

    newData.doctors.forEach(d => {
        d.status = Math.random() > 0.5 ? 'Available' : 'Busy';
    });

    return newData;
}

function renderMultiHospitalWards() {
    const container = document.getElementById('wards-container');
    if (!container) return;

    container.innerHTML = '';

    const hospIds = getAllHospitalIds();
    const filterValue = document.getElementById('bed-hospital-filter')?.value || 'all';

    hospIds.forEach(hid => {
        if (filterValue !== 'all' && hid !== filterValue) return;

        const key = `nhm_state_${hid}`;
        const data = JSON.parse(localStorage.getItem(key)) || defaultState;
        const hospName = getHospitalName(hid);

        // Hospital Section Header
        const hospHeader = document.createElement('div');
        hospHeader.className = 'hosp-section-header';
        hospHeader.style = "grid-column: 1 / -1; margin-top: 25px; padding: 10px; border-bottom: 2px solid #eee; display: flex; align-items: center; gap: 10px;";

        hospHeader.innerHTML = `<i class="fa-solid fa-hospital" style="color: var(--primary-color);"></i> <h3 style="margin:0; font-size: 1.1rem;">${hospName}</h3>`;
        container.appendChild(hospHeader);

        // Group rows of wards for this hospital
        const wardsWrapper = document.createElement('div');
        wardsWrapper.className = 'wards-grid';
        wardsWrapper.style = "grid-column: 1 / -1; display: grid; grid-template-columns: repeat(auto-fit, minmax(320px, 1fr)); gap: 20px; margin-top: 15px;";

        data.wards.forEach(w => {
            const pct = w.occupied / w.capacity;
            let badgeClass = 'stable';
            if (pct >= 0.9) badgeClass = 'critical';
            else if (pct >= 0.7) badgeClass = 'warning';

            const card = document.createElement('div');
            card.className = 'ward-card';
            card.innerHTML = `
                <div class="ward-header">
                    <h3>${w.name}</h3>
                    <span class="ward-badge ${badgeClass}">${Math.round(pct * 100)}% Occ.</span>
                </div>
                <div class="ward-body">
                    <p style="font-size:0.85rem; color:var(--text-muted); margin-bottom:8px;">${w.capacity - w.occupied} / ${w.capacity} Beds Available</p>
                    <div class="progress-bar-container" style="height:6px;">
                        <div class="progress-bar ${w.type}" style="width: ${pct * 100}%"></div>
                    </div>
                </div>
            `;
            wardsWrapper.appendChild(card);
        });
        container.appendChild(wardsWrapper);
    });
}

function renderSingleHospitalWards(hospId) {
    const container = document.getElementById('wards-container');
    if (!container) return;

    container.innerHTML = '';

    const key = `nhm_state_${hospId}`;
    const data = JSON.parse(localStorage.getItem(key)) || defaultState;
    const hospName = getHospitalName(hospId);

    // Hospital Section Header
    const hospHeader = document.createElement('div');
    hospHeader.className = 'hosp-section-header';
    hospHeader.style = "grid-column: 1 / -1; margin-top: 25px; padding: 10px; border-bottom: 2px solid #eee; display: flex; align-items: center; gap: 10px;";

    hospHeader.innerHTML = `<i class="fa-solid fa-hospital" style="color: var(--primary-color);"></i> <h3 style="margin:0; font-size: 1.1rem;">${hospName}</h3>`;
    container.appendChild(hospHeader);

    // Group rows of wards for this hospital
    const wardsWrapper = document.createElement('div');
    wardsWrapper.className = 'wards-grid';
    wardsWrapper.style = "grid-column: 1 / -1; display: grid; grid-template-columns: repeat(auto-fit, minmax(320px, 1fr)); gap: 20px; margin-top: 15px;";

    data.wards.forEach(w => {
        const pct = w.occupied / w.capacity;
        let badgeClass = 'stable';
        if (pct >= 0.9) badgeClass = 'critical';
        else if (pct >= 0.7) badgeClass = 'warning';

        const card = document.createElement('div');
        card.className = 'ward-card';
        card.innerHTML = `
            <div class="ward-header">
                <h3>${w.name}</h3>
                <span class="ward-badge ${badgeClass}">${Math.round(pct * 100)}% Occ.</span>
            </div>
            <div class="ward-body">
                <p style="font-size:0.85rem; color:var(--text-muted); margin-bottom:8px;">${w.capacity - w.occupied} / ${w.capacity} Beds Available</p>
                <div class="progress-bar-container" style="height:6px;">
                    <div class="progress-bar ${w.type}" style="width: ${pct * 100}%"></div>
                </div>
            </div>
        `;
        wardsWrapper.appendChild(card);
    });
    container.appendChild(wardsWrapper);
}

function renderHospitalAssignments() {
    const container = document.getElementById('hospitals-assignments-container');
    if (!container) return;
    container.innerHTML = '';

    const hospIds = getAllHospitalIds();

    hospIds.forEach(hid => {
        const key = `nhm_state_${hid}`;
        const data = JSON.parse(localStorage.getItem(key)) || defaultState;
        const hospName = getHospitalName(hid);

        const card = document.createElement('div');
        card.className = 'card hospital-assignment-card';
        card.style = "margin-bottom: 30px; border-left: 4px solid var(--primary-color);";

        let docListHtml = '';
        data.doctors.forEach(doc => {
            docListHtml += `
                <div style="padding: 10px; border-bottom: 1px solid #f0f0f0; display:flex; justify-content:space-between; align-items:center;">
                    <div>
                        <span style="font-weight:600;">${doc.name}</span>
                        <span style="font-size: 0.8rem; color: #666; margin-left: 10px;">${doc.specs}</span>
                    </div>
                    <span class="status-badge ${doc.status === 'Available' ? 'status-good' : 'status-busy'}" style="font-size:0.7rem;">${doc.status}</span>
                </div>
            `;
        });

        card.innerHTML = `
            <div class="card-header" style="background: #f8f9fa;">
                <h3 style="margin:0;"><i class="fa-solid fa-hospital"></i> ${hospName}</h3>
                <span class="btn-text">${data.doctors.length} Assigned Doctors</span>
            </div>
            <div class="card-body">
                <h4 style="font-size: 0.9rem; color: var(--text-muted); margin-bottom: 15px; text-transform: uppercase;">Staff Assignments</h4>
                ${docListHtml}
            </div>
        `;
        container.appendChild(card);
    });
}

function updateDashboardStats() {
    // Original function for single hospital view
    const totalDoctors = hospitalState.doctors.length;

    let totalBeds = 0;
    let occupiedBeds = 0;
    let icuAvailable = 0;

    hospitalState.wards.forEach(w => {
        totalBeds += w.capacity;
        occupiedBeds += w.occupied;
        if (w.type === 'icu' || w.type === 'emergency') {
            icuAvailable += (w.capacity - w.occupied);
        }
    });

    const availableBeds = totalBeds - occupiedBeds;
    const activeAppointments = hospitalState.appointments.filter(a => a.status === 'Confirmed').length;

    document.getElementById('stat-doctors') && (document.getElementById('stat-doctors').textContent = totalDoctors);
    document.getElementById('stat-beds') && (document.getElementById('stat-beds').textContent = availableBeds);
    document.getElementById('stat-appointments') && (document.getElementById('stat-appointments').textContent = activeAppointments);
    document.getElementById('stat-icu') && (document.getElementById('stat-icu').textContent = `${icuAvailable} Available`);

    // Recent bookings
    const recentList = document.getElementById('recent-bookings-list');
    if (recentList) {
        recentList.innerHTML = '';
        const recentApts = [...hospitalState.appointments].reverse().slice(0, 5);

        recentApts.forEach(apt => {
            const doc = hospitalState.doctors.find(d => d.id === apt.doctorId);
            const li = document.createElement('li');
            li.className = 'booking-item';

            let statusClass = apt.status === 'Confirmed' ? 'status-confirmed' : 'status-cancelled';

            li.innerHTML = `
                <div class="booking-info">
                    <h4>${apt.patientName} <span style="font-size:0.8rem; color:var(--text-muted)">• ${apt.slotTime}</span></h4>
                    <p>with ${doc ? doc.name : 'Unknown'} - ${doc ? doc.dept : ''}</p>
                </div>
                <div class="booking-status ${statusClass}">${apt.status}</div>
            `;
            recentList.appendChild(li);
        });
    }

    // Occupancy bars
    const occupancyContainer = document.getElementById('occupancy-summary');
    if (occupancyContainer) {
        occupancyContainer.innerHTML = '';

        hospitalState.wards.forEach(w => {
            const pct = w.capacity > 0 ? Math.round((w.occupied / w.capacity) * 100) : 0;
            const div = document.createElement('div');
            div.className = 'progress-group';
            div.innerHTML = `
                <div class="progress-label">
                    <span>${w.name}</span>
                    <span>${w.occupied} / ${w.capacity} (${pct}%)</span>
                </div>
                <div class="progress-bar-container">
                    <div class="progress-bar ${w.type}" style="width: ${pct}%"></div>
                </div>
            `;
            occupancyContainer.appendChild(div);
        });
    }
}

// ... (keep all other existing functions like populateForms, setupBookingForm, 
// renderWardsGrid, setupAdminControls, showToast, etc.)

// --- TOAST ---
let toastTimeout;
function showToast(title, message) {
    const toast = document.getElementById('toast');
    if (!toast) {
        console.log(`NHM Toast: ${title} - ${message}`);
        return;
    }

    const toastTitle = toast.querySelector('.toast-title');
    const toastMessage = toast.querySelector('.toast-message');

    if (toastTitle) toastTitle.textContent = title;
    if (toastMessage) toastMessage.textContent = message;

    toast.classList.remove('hidden');
    toast.style.display = 'block';
    void toast.offsetWidth;
    toast.classList.add('show');

    clearTimeout(toastTimeout);
    toastTimeout = setTimeout(() => {
        toast.classList.remove('show');
        setTimeout(() => {
            toast.classList.add('hidden');
            toast.style.display = 'none';
        }, 300);
    }, 4000);
}

const toastClose = document.querySelector('.toast-close');
if (toastClose) {
    toastClose.addEventListener('click', () => {
        const toast = document.getElementById('toast');
        if (toast) {
            toast.classList.remove('show');
            setTimeout(() => {
                toast.classList.add('hidden');
                toast.style.display = 'none';
            }, 300);
        }
    });
}