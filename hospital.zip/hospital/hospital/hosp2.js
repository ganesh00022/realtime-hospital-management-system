// hosp2.js - Logic for Lifecare Hospital (Hosp2)
// Custom Data: Focused on Maternity and General Care

const defaultState = {
    doctors: [
        { id: 'd1', name: 'Dr. Sanjay Dutt', dept: 'Cardiology', maxSlots: 6, specs: 'Cardiac Surgeon', status: 'Available' },
        { id: 'd2', name: 'Dr. Meena Iyer', dept: 'Orthopedics', maxSlots: 5, specs: 'Spine Specialist', status: 'Busy' },
        { id: 'd3', name: 'Dr. Anil Kapoor', dept: 'Neurology', maxSlots: 4, specs: 'Neuro Consultant', status: 'Available' }
    ],
    wards: [
        { id: 'w1', name: 'Cardiac Care Unit', type: 'icu', capacity: 12, occupied: 4 },
        { id: 'w2', name: 'Ortho Ward', type: 'general', capacity: 30, occupied: 12 },
        { id: 'w3', name: 'Executive Suite', type: 'private', capacity: 10, occupied: 2 }
    ],
    appointments: [],
    bookedSlots: {},
    emergencyMode: false
};

// Unique Key for Hosp 2
const STORAGE_KEY = 'nhm_state_HOSP-MUM-02';

let hospitalState = JSON.parse(localStorage.getItem(STORAGE_KEY)) || defaultState;
let currentUser = JSON.parse(localStorage.getItem('nhm_current_user')) || { name: 'Admin', role: 'admin' };

function saveState() {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(hospitalState));
    // Note: We don't overwrite the shared 'nhm_state' here unless this is the "active" patient view hospital.
    // Ideally, the patient view should also select a hospital. For now, we only update our own key.
}

// --- INITIALIZATION ---
document.addEventListener('DOMContentLoaded', () => {
    // Check Auth
    if (currentUser.id !== 'HOSP-MUM-02' && currentUser.id !== 'admin' && currentUser.role !== 'admin') {
        console.warn('Access Context Mismatch');
    }

    setupNavigation();
    initModules();
    startRealTimeUpdates();
});

function initModules() {
    updateAnalytics();
    renderDocMgmt();
    setupSlotManager();
    renderBedMgmt('all');
    setupBedActions();
    setupEmergencyControl();
}

function startRealTimeUpdates() {
    setInterval(() => {
        const storedState = JSON.parse(localStorage.getItem(STORAGE_KEY));
        if (storedState) {
            hospitalState = storedState;
            updateAnalytics();
            if (document.querySelector('.nav-item[data-view="beds"]').classList.contains('active')) {
                const activeFilter = document.querySelector('.filter-btn.active')?.getAttribute('data-ward') || 'all';
                renderBedMgmt(activeFilter);
            }
        }
    }, 5000);
}

// --- NAVIGATION ---
function setupNavigation() {
    const navItems = document.querySelectorAll('.nav-item');
    const views = document.querySelectorAll('.view');

    navItems.forEach(item => {
        item.addEventListener('click', () => {
            navItems.forEach(nav => nav.classList.remove('active'));
            item.classList.add('active');

            const targetViewId = item.getAttribute('data-view');
            views.forEach(view => {
                view.classList.remove('active');
                view.classList.add('hidden');
            });
            document.getElementById(targetViewId).classList.remove('hidden');
            document.getElementById(targetViewId).classList.add('active');

            if (targetViewId === 'doctors') renderDocMgmt();
            if (targetViewId === 'beds') renderBedMgmt('all');
        });
    });

    document.getElementById('btn-logout').addEventListener('click', () => {
        localStorage.removeItem('nhm_current_user');
        localStorage.removeItem('isLoggedIn');
        window.location.href = 'login.html';
    });
}

// --- 1. ANALYTICS ---
function updateAnalytics() {
    let totalBeds = 0, occupiedBeds = 0;
    hospitalState.wards.forEach(w => { totalBeds += w.capacity; occupiedBeds += w.occupied; });
    const freeBeds = totalBeds - occupiedBeds;
    const occupancyRate = totalBeds > 0 ? Math.round((occupiedBeds / totalBeds) * 100) : 0;
    const availDocs = hospitalState.doctors.filter(d => d.status === 'Available').length;
    const set = (id, val) => { const el = document.getElementById(id); if (el) el.textContent = val; };
    set('stat-occupancy-rate', occupancyRate + '%');
    set('stat-avail-docs', availDocs + ' / ' + hospitalState.doctors.length);
    set('stat-free-beds', freeBeds + ' beds');
    set('stat-emergency-status', hospitalState.emergencyMode ? '🚨 ACTIVE' : 'Normal');
    set('analytics-total-beds', totalBeds);
    set('analytics-occ-beds', occupiedBeds);
    set('analytics-avail-docs', availDocs);
    set('analytics-occ-rate', occupancyRate + '%');
    const banner = document.getElementById('emergency-banner');
    if (banner) banner.style.display = hospitalState.emergencyMode ? 'block' : 'none';
    const odoc = document.getElementById('overview-doctor-table');
    if (odoc) {
        odoc.innerHTML = '';
        hospitalState.doctors.forEach(doc => {
            const color = doc.status === 'Available' ? '#16a34a' : doc.status === 'In Surgery' ? '#dc2626' : '#f59e0b';
            odoc.innerHTML += `<tr>
                <td><strong>${doc.name}</strong></td>
                <td>${doc.dept}</td>
                <td><span style="color:${color};font-weight:700">${doc.status}</span></td>
            </tr>`;
        });
    }
    const oward = document.getElementById('overview-ward-table');
    if (oward) {
        oward.innerHTML = '';
        hospitalState.wards.forEach(w => {
            oward.innerHTML += `<tr>
                <td><strong>${w.name}</strong></td>
                <td>${w.capacity}</td>
                <td style="color:#dc2626;font-weight:700">${w.occupied}</td>
                <td style="color:#16a34a;font-weight:700">${w.capacity - w.occupied}</td>
            </tr>`;
        });
    }
    const awd = document.getElementById('analytics-ward-breakdown');
    if (awd) { awd.innerHTML = ''; hospitalState.wards.forEach(w => { const pct = w.capacity > 0 ? Math.round((w.occupied / w.capacity) * 100) : 0; awd.innerHTML += `<tr><td>${w.name}</td><td>${w.capacity}</td><td>${w.occupied}</td><td>${w.capacity - w.occupied}</td><td><strong>${pct}%</strong></td></tr>`; }); }
    const adoc = document.getElementById('analytics-doc-table');
    if (adoc) { adoc.innerHTML = ''; hospitalState.doctors.forEach(doc => { adoc.innerHTML += `<tr><td>${doc.name}</td><td>${doc.dept}</td><td>${doc.maxSlots}</td><td>${doc.status}</td></tr>`; }); }
}



// --- 2. DOCTOR MANAGEMENT ---
function renderDocMgmt() {
    const tbody = document.getElementById('doc-mgmt-table');
    tbody.innerHTML = '';

    hospitalState.doctors.forEach(doc => {
        const tr = document.createElement('tr');
        let statusBadge = '';
        if (doc.status === 'Available') statusBadge = '<span class="status-badge status-good">Available</span>';
        else if (doc.status === 'In Surgery') statusBadge = '<span class="status-badge status-busy">In Surgery</span>';
        else statusBadge = '<span class="status-badge status-busy" style="opacity:0.7">Off Duty</span>';

        tr.innerHTML = `
            <td>
                <strong>${doc.name}</strong><br>
                <small class="text-muted">${doc.specs}</small>
            </td>
            <td>${doc.dept}</td>
            <td>${statusBadge}</td>
            <td>${Math.floor(Math.random() * 20)}</td>
            <td>
                <button class="btn btn-sm btn-outline"><i class="fa-solid fa-pen"></i></button>
            </td>
        `;
        tbody.appendChild(tr);
    });
}

// --- 3. APPOINTMENTS & SLOTS ---
function setupSlotManager() {
    const select = document.getElementById('slot-mgmt-doc-select');
    select.innerHTML = '<option value="" disabled selected>Select Doctor</option>';

    hospitalState.doctors.forEach(doc => {
        const opt = document.createElement('option');
        opt.value = doc.id;
        opt.textContent = doc.name;
        select.appendChild(opt);
    });

    select.addEventListener('change', (e) => {
        const docId = e.target.value;
        renderAdminSlots(docId);
    });
}

function renderAdminSlots(docId) {
    const container = document.getElementById('admin-slot-grid');
    container.innerHTML = '';

    const doc = hospitalState.doctors.find(d => d.id === docId);
    const booked = hospitalState.bookedSlots[docId] || [];
    const masterSlots = [
        "09:00 AM", "09:30 AM", "10:00 AM", "10:30 AM", "11:00 AM", "02:00 PM", "03:00 PM", "04:00 PM"
    ];

    masterSlots.forEach(slot => {
        const badge = document.createElement('div');
        const isBooked = booked.includes(slot);
        badge.className = `slot-badge ${isBooked ? 'booked' : 'available'}`;
        badge.textContent = slot;
        container.appendChild(badge);
    });

    const total = masterSlots.length;
    const bookedCount = booked.length;
    document.getElementById('slot-stats').textContent = `Total Slots: ${total} | Booked: ${bookedCount}`;
}

// --- 4. BED MANAGEMENT ---
function renderBedMgmt(filter) {
    const container = document.getElementById('adm-wards-container');
    container.innerHTML = '';

    document.querySelectorAll('.filter-btn').forEach(b => {
        b.classList.remove('active');
        if (b.getAttribute('data-ward') === filter) b.classList.add('active');
    });

    let wards = hospitalState.wards;
    if (filter !== 'all') wards = hospitalState.wards.filter(w => w.type === filter);

    wards.forEach(w => {
        const pct = Math.round((w.occupied / w.capacity) * 100);
        const card = document.createElement('div');
        card.className = 'ward-card';
        card.innerHTML = `
            <div class="ward-header">
                <h3>${w.name}</h3>
                <span class="ward-badge ${pct > 90 ? 'critical' : 'stable'}">${w.type.toUpperCase()}</span>
            </div>
            <div class="ward-body">
                <div class="progress-group">
                    <div class="progress-bar-container">
                        <div class="progress-bar ${w.type}" style="width:${pct}%"></div>
                    </div>
                </div>
                <div style="display:flex; justify-content:space-between; margin-top:10px;">
                     <div style="text-align:center"><h4 style="color:var(--success-color)">${w.capacity - w.occupied}</h4><small>Free</small></div>
                </div>
            </div>
         `;
        container.appendChild(card);
    });

    updateBedCountBig();

    const select = document.getElementById('bed-mgmt-ward-select');
    const currentVal = select.value;
    select.innerHTML = '<option value="" disabled selected>Select Ward to Update</option>';
    hospitalState.wards.forEach(w => {
        const opt = document.createElement('option');
        opt.value = w.id;
        opt.textContent = `${w.name} (Free: ${w.capacity - w.occupied})`;
        select.appendChild(opt);
    });
    if (currentVal) select.value = currentVal;
}

function updateBedCountBig() {
    let free = 0;
    hospitalState.wards.forEach(w => free += (w.capacity - w.occupied));
    document.querySelector('#live-bed-counter h2').textContent = free;
}

function setupBedActions() {
    document.getElementById('btn-adm-admit').addEventListener('click', () => {
        const wardId = document.getElementById('bed-mgmt-ward-select').value;
        if (!wardId) return alert('Select a ward first');
        const ward = hospitalState.wards.find(w => w.id === wardId);
        if (ward && ward.occupied < ward.capacity) {
            ward.occupied++;
            saveState();
            renderBedMgmt('all');
            updateAnalytics();
            showToast('Success', 'Patient Admitted.');
        } else {
            alert('Ward Full!');
        }
    });

    document.getElementById('btn-adm-discharge').addEventListener('click', () => {
        const wardId = document.getElementById('bed-mgmt-ward-select').value;
        if (!wardId) return alert('Select a ward first');
        const ward = hospitalState.wards.find(w => w.id === wardId);
        if (ward && ward.occupied > 0) {
            ward.occupied--;
            saveState();
            renderBedMgmt('all');
            updateAnalytics();
            showToast('Success', 'Patient Discharged.');
        } else {
            alert('Ward Empty!');
        }
    });
}

// --- 5. EMERGENCY CONTROL ---
function setupEmergencyControl() {
    const toggle = document.getElementById('emergency-mode-toggle');
    toggle.checked = hospitalState.emergencyMode || false;

    toggle.addEventListener('change', (e) => {
        hospitalState.emergencyMode = e.target.checked;
        saveState();
        updateAnalytics();
        if (hospitalState.emergencyMode) alert('🚨 EMERGENCY MODE ACTIVATED 🚨');
    });
}

// --- UTILS ---
function showToast(title, message) {
    const toast = document.getElementById('toast');
    toast.querySelector('.toast-title').textContent = title;
    toast.querySelector('.toast-message').textContent = message;
    toast.classList.remove('hidden');
    toast.classList.add('show');
    setTimeout(() => {
        toast.classList.remove('show');
        setTimeout(() => toast.classList.add('hidden'), 300);
    }, 3000);
}
