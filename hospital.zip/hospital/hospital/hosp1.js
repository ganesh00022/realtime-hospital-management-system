// hosp1.js - Logic for Advanced Hospital Dashboard

// --- SHARED STATE ACCESS ---
// We use the same 'nhm_state' key to stay in sync with Patient Dashboard
const defaultState = {
    doctors: [
        { id: 'd1', name: 'Dr. Arnab Sen', dept: 'Oncology', maxSlots: 5, specs: 'Cancer Specialist', status: 'Available' },
        { id: 'd2', name: 'Dr. Rita Gupta', dept: 'Surgery', maxSlots: 4, specs: 'Transplant Surgeon', status: 'In Surgery' },
        { id: 'd3', name: 'Dr. Vikram Seth', dept: 'Radiology', maxSlots: 6, specs: 'Diagnostic Lead', status: 'Available' }
    ],
    wards: [
        { id: 'w1', name: 'Chemotherapy Wing', type: 'specialized', capacity: 20, occupied: 5 },
        { id: 'w2', name: 'Surgical ICU', type: 'icu', capacity: 15, occupied: 10 },
        { id: 'w3', name: 'General Ward', type: 'general', capacity: 50, occupied: 20 }
    ],
    appointments: [],
    bookedSlots: {},
    emergencyMode: false
};

// Unique Key for Tata Memorial
const STORAGE_KEY = 'nhm_state_HOSP-MUM-01';
// The Master Admin Dashboard will read this key.

let hospitalState = JSON.parse(localStorage.getItem(STORAGE_KEY)) || defaultState;
let currentUser = JSON.parse(localStorage.getItem('nhm_current_user')) || { name: 'Admin', role: 'admin' };

function saveState() {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(hospitalState));
    // Also update the shared 'nhm_state' for the patient view (index.html)
    // In a real app, the backend would aggregate this. For now, Hosp1 is the default "User View" provider.
    localStorage.setItem('nhm_state', JSON.stringify(hospitalState));
}

// --- INITIALIZATION ---
document.addEventListener('DOMContentLoaded', () => {
    // Check Auth (Loose check for demo)
    if (currentUser.id !== 'HOSP-MUM-01' && currentUser.id !== 'admin') {
        // alert('Access Restricted. Demo Mode only.');
    }

    setupNavigation();
    initModules();
    startRealTimeUpdates();
});

function initModules() {
    updateAnalytics();
    renderDocMgmt();
    setupSlotManager();
    renderBedMgmt('all');
    setupBedActions();
    setupEmergencyControl();
}

function startRealTimeUpdates() {
    // Poll for changes (simulating real-time sync with other users/patients)
    setInterval(() => {
        const storedState = JSON.parse(localStorage.getItem(STORAGE_KEY));
        if (storedState) {
            // Merge logic could go here, for now simpler overwrite if changed externally
            // But we are the admin, so we mostly push changes.
            // Let's just refresh counters
            hospitalState = storedState;
            updateAnalytics();
            // Refreshes bed grid if active
            if (document.querySelector('.nav-item[data-view="beds"]').classList.contains('active')) {
                const activeFilter = document.querySelector('.filter-btn.active')?.getAttribute('data-ward') || 'all';
                renderBedMgmt(activeFilter);
            }
        }
    }, 5000);
}

// --- NAVIGATION ---
function setupNavigation() {
    const navItems = document.querySelectorAll('.nav-item');
    const views = document.querySelectorAll('.view');

    navItems.forEach(item => {
        item.addEventListener('click', () => {
            navItems.forEach(nav => nav.classList.remove('active'));
            item.classList.add('active');

            const targetViewId = item.getAttribute('data-view');
            views.forEach(view => {
                view.classList.remove('active');
                view.classList.add('hidden');
            });
            document.getElementById(targetViewId).classList.remove('hidden');
            document.getElementById(targetViewId).classList.add('active');

            // Refresh specific views
            if (targetViewId === 'doctors') renderDocMgmt();
            if (targetViewId === 'beds') renderBedMgmt('all');
        });
    });

    document.getElementById('btn-logout').addEventListener('click', () => {
        localStorage.removeItem('nhm_current_user');
        localStorage.removeItem('isLoggedIn');
        window.location.href = 'login.html';
    });
}

// --- 1. ANALYTICS ---
function updateAnalytics() {
    let totalBeds = 0, occupiedBeds = 0;
    hospitalState.wards.forEach(w => { totalBeds += w.capacity; occupiedBeds += w.occupied; });
    const freeBeds = totalBeds - occupiedBeds;
    const occupancyRate = totalBeds > 0 ? Math.round((occupiedBeds / totalBeds) * 100) : 0;
    const availDocs = hospitalState.doctors.filter(d => d.status === 'Available').length;

    // Overview Stats
    const set = (id, val) => { const el = document.getElementById(id); if (el) el.textContent = val; };
    set('stat-occupancy-rate', occupancyRate + '%');
    set('stat-avail-docs', availDocs + ' / ' + hospitalState.doctors.length);
    set('stat-free-beds', freeBeds + ' beds');
    set('stat-emergency-status', hospitalState.emergencyMode ? '🚨 ACTIVE' : 'Normal');

    // Analytics Section Stats
    set('analytics-total-beds', totalBeds);
    set('analytics-occ-beds', occupiedBeds);
    set('analytics-avail-docs', availDocs);
    set('analytics-occ-rate', occupancyRate + '%');

    // Emergency Banner
    const banner = document.getElementById('emergency-banner');
    if (banner) banner.style.display = hospitalState.emergencyMode ? 'block' : 'none';

    // Overview Doctor Table
    const odoc = document.getElementById('overview-doctor-table');
    if (odoc) {
        odoc.innerHTML = '';
        hospitalState.doctors.forEach(doc => {
            const color = doc.status === 'Available' ? '#16a34a' : doc.status === 'In Surgery' ? '#dc2626' : '#f59e0b';
            odoc.innerHTML += `<tr>
                <td><strong>${doc.name}</strong></td>
                <td>${doc.dept}</td>
                <td><span style="color:${color};font-weight:700">${doc.status}</span></td>
            </tr>`;
        });
    }

    // Overview Ward Table
    const oward = document.getElementById('overview-ward-table');
    if (oward) {
        oward.innerHTML = '';
        hospitalState.wards.forEach(w => {
            const pct = w.capacity > 0 ? Math.round((w.occupied / w.capacity) * 100) : 0;
            const color = pct > 80 ? '#dc2626' : pct > 50 ? '#f59e0b' : '#16a34a';
            oward.innerHTML += `<tr>
                <td><strong>${w.name}</strong></td>
                <td>${w.capacity}</td>
                <td style="color:#dc2626;font-weight:700">${w.occupied}</td>
                <td style="color:#16a34a;font-weight:700">${w.capacity - w.occupied}</td>
            </tr>`;
        });
    }

    // Analytics Ward Breakdown
    const awd = document.getElementById('analytics-ward-breakdown');
    if (awd) {
        awd.innerHTML = '';
        hospitalState.wards.forEach(w => {
            const pct = w.capacity > 0 ? Math.round((w.occupied / w.capacity) * 100) : 0;
            awd.innerHTML += `<tr>
                <td>${w.name}</td><td>${w.capacity}</td>
                <td>${w.occupied}</td><td>${w.capacity - w.occupied}</td>
                <td><strong>${pct}%</strong></td>
            </tr>`;
        });
    }

    // Analytics Doctor Table
    const adoc = document.getElementById('analytics-doc-table');
    if (adoc) {
        adoc.innerHTML = '';
        hospitalState.doctors.forEach(doc => {
            adoc.innerHTML += `<tr>
                <td>${doc.name}</td><td>${doc.dept}</td>
                <td>${doc.maxSlots}</td><td>${doc.status}</td>
            </tr>`;
        });
    }
}

// --- 2. DOCTOR MANAGEMENT ---
function renderDocMgmt() {
    const tbody = document.getElementById('doc-mgmt-table');
    tbody.innerHTML = '';

    hospitalState.doctors.forEach(doc => {
        const tr = document.createElement('tr');
        let statusBadge = '';
        if (doc.status === 'Available') statusBadge = '<span class="status-badge status-good">Available</span>';
        else if (doc.status === 'In Surgery') statusBadge = '<span class="status-badge status-busy">In Surgery</span>';
        else statusBadge = '<span class="status-badge status-busy" style="opacity:0.7">Off Duty</span>';

        tr.innerHTML = `
            <td><strong>${doc.name}</strong><br><small class="text-muted">${doc.specs}</small></td>
            <td>${doc.dept}</td>
            <td>${statusBadge}</td>
            <td>${doc.maxSlots} slots/day</td>
            <td>
                <button class="btn btn-sm btn-outline"><i class="fa-solid fa-pen"></i></button>
            </td>
        `;
        tbody.appendChild(tr);
    });
}

// --- 3. APPOINTMENTS & SLOTS ---
function setupSlotManager() {
    const select = document.getElementById('slot-mgmt-doc-select');
    select.innerHTML = '<option value="" disabled selected>Select Doctor</option>';

    hospitalState.doctors.forEach(doc => {
        const opt = document.createElement('option');
        opt.value = doc.id;
        opt.textContent = doc.name;
        select.appendChild(opt);
    });

    select.addEventListener('change', (e) => {
        const docId = e.target.value;
        renderAdminSlots(docId);
    });
}

function renderAdminSlots(docId) {
    const container = document.getElementById('admin-slot-grid');
    container.innerHTML = '';

    const doc = hospitalState.doctors.find(d => d.id === docId);
    const booked = hospitalState.bookedSlots[docId] || [];
    const masterSlots = [
        "09:00 AM", "09:30 AM", "10:00 AM", "10:30 AM",
        "11:00 AM", "11:30 AM", "02:00 PM", "02:30 PM",
        "03:00 PM", "03:30 PM", "04:00 PM", "04:30 PM"
    ];

    masterSlots.forEach(slot => {
        const badge = document.createElement('div');
        const isBooked = booked.includes(slot);

        badge.className = `slot-badge ${isBooked ? 'booked' : 'available'}`;
        badge.textContent = slot;
        badge.title = isBooked ? 'Booked by Patient' : 'Click to Block'; // Simplification

        container.appendChild(badge);
    });

    // Update simple stats
    const total = masterSlots.length;
    const bookedCount = booked.length;
    document.getElementById('slot-stats').textContent = `Total Slots: ${total} | Booked: ${bookedCount} | Remaining: ${total - bookedCount}`;
}

// --- 4. BED MANAGEMENT ---
function renderBedMgmt(filter) {
    const container = document.getElementById('adm-wards-container');
    container.innerHTML = '';

    // Filter logic
    document.querySelectorAll('.filter-btn').forEach(b => {
        b.classList.remove('active');
        if (b.getAttribute('data-ward') === filter) b.classList.add('active');
    });

    let wards = hospitalState.wards;
    if (filter !== 'all') wards = hospitalState.wards.filter(w => w.type === filter);

    wards.forEach(w => {
        // Re-using the card logic but focusing on admin numbers
        const pct = Math.round((w.occupied / w.capacity) * 100);
        const card = document.createElement('div');
        card.className = 'ward-card'; // Reuse style
        card.innerHTML = `
            <div class="ward-header">
                <h3>${w.name}</h3>
                <span class="ward-badge ${pct > 90 ? 'critical' : 'stable'}">${w.type.toUpperCase()}</span>
            </div>
            <div class="ward-body">
                <div class="progress-group">
                    <div class="progress-bar-container">
                        <div class="progress-bar ${w.type}" style="width:${pct}%"></div>
                    </div>
                </div>
                <div style="display:flex; justify-content:space-between; margin-top:10px;">
                    <div style="text-align:center">
                        <h4>${w.capacity}</h4>
                        <small>Total</small>
                    </div>
                    <div style="text-align:center">
                        <h4 style="color:var(--danger-color)">${w.occupied}</h4>
                        <small>Occupied</small>
                    </div>
                     <div style="text-align:center">
                        <h4 style="color:var(--success-color)">${w.capacity - w.occupied}</h4>
                        <small>Free</small>
                    </div>
                </div>
            </div>
         `;
        container.appendChild(card);
    });

    updateBedCountBig();

    // Populate dropdown
    const select = document.getElementById('bed-mgmt-ward-select');
    // Save current selection to avoid jump
    const currentVal = select.value;
    select.innerHTML = '<option value="" disabled selected>Select Ward to Update</option>';
    hospitalState.wards.forEach(w => {
        const opt = document.createElement('option');
        opt.value = w.id;
        opt.textContent = `${w.name} (Free: ${w.capacity - w.occupied})`;
        select.appendChild(opt);
    });
    if (currentVal) select.value = currentVal;
}

function updateBedCountBig() {
    let free = 0;
    hospitalState.wards.forEach(w => free += (w.capacity - w.occupied));
    document.querySelector('#live-bed-counter h2').textContent = free;
}

function setupBedActions() {
    // Admit
    document.getElementById('btn-adm-admit').addEventListener('click', () => {
        const wardId = document.getElementById('bed-mgmt-ward-select').value;
        if (!wardId) return alert('Select a ward first');

        const ward = hospitalState.wards.find(w => w.id === wardId);
        if (ward && ward.occupied < ward.capacity) {
            ward.occupied++;
            saveState();
            renderBedMgmt('all'); // Refresh
            updateAnalytics();
            showToast('Success', 'Patient Admitted. Bed Count Updated.');
        } else {
            alert('Ward Full!');
        }
    });

    // Discharge
    document.getElementById('btn-adm-discharge').addEventListener('click', () => {
        const wardId = document.getElementById('bed-mgmt-ward-select').value;
        if (!wardId) return alert('Select a ward first');

        const ward = hospitalState.wards.find(w => w.id === wardId);
        if (ward && ward.occupied > 0) {
            ward.occupied--;
            saveState();
            renderBedMgmt('all');
            updateAnalytics();
            showToast('Success', 'Patient Discharged. Bed Released.');
        } else {
            alert('Ward Empty!');
        }
    });

    document.querySelector('.ward-filters').addEventListener('click', (e) => {
        if (e.target.classList.contains('filter-btn')) {
            renderBedMgmt(e.target.getAttribute('data-ward'));
        }
    });
}

// --- 5. EMERGENCY CONTROL ---
function setupEmergencyControl() {
    const toggle = document.getElementById('emergency-mode-toggle');
    toggle.checked = hospitalState.emergencyMode || false;

    toggle.addEventListener('change', (e) => {
        hospitalState.emergencyMode = e.target.checked;
        saveState();
        updateAnalytics();

        if (hospitalState.emergencyMode) {
            alert('🚨 EMERGENCY MODE ACTIVATED 🚨\nAll non-critical bookings are now suspended.\nStaff notified.');
        } else {
            showToast('Mode Deactivated', 'Hospital returned to normal operations.');
        }
    });
}

// --- UTILS ---
function showToast(title, message) {
    const toast = document.getElementById('toast');
    toast.querySelector('.toast-title').textContent = title;
    toast.querySelector('.toast-message').textContent = message;
    toast.classList.remove('hidden');
    toast.classList.add('show');
    setTimeout(() => {
        toast.classList.remove('show');
        setTimeout(() => toast.classList.add('hidden'), 300);
    }, 3000);
}
