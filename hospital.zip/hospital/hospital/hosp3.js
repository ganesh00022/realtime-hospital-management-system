// hosp3.js - Logic for Sunlight Medical Center (Hosp3)
// Custom Data: Neurology and Dermatology Focus

const defaultState = {
    doctors: [
        { id: 'd1', name: 'Dr. Sunita Rao', dept: 'Gynecology', maxSlots: 8, specs: 'Fertility Specialist', status: 'Available' },
        { id: 'd2', name: 'Dr. Rahul Bajaj', dept: 'Pediatrics', maxSlots: 7, specs: 'Child Specialist', status: 'Available' },
        { id: 'd3', name: 'Dr. Amrita Singh', dept: 'General Medicine', maxSlots: 10, specs: 'Physician', status: 'On Leave' }
    ],
    wards: [
        { id: 'w1', name: 'Maternity Ward', type: 'maternity', capacity: 40, occupied: 15 },
        { id: 'w2', name: 'NICU', type: 'icu', capacity: 15, occupied: 8 },
        { id: 'w3', name: 'Observation Ward', type: 'general', capacity: 25, occupied: 10 }
    ],
    appointments: [],
    bookedSlots: {},
    emergencyMode: false
};

const STORAGE_KEY = 'nhm_state_HOSP-MUM-03';

let hospitalState = JSON.parse(localStorage.getItem(STORAGE_KEY)) || defaultState;
let currentUser = JSON.parse(localStorage.getItem('nhm_current_user')) || { name: 'Admin', role: 'admin' };

function saveState() {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(hospitalState));
}

// Reuse similar logic structure
document.addEventListener('DOMContentLoaded', () => {
    if (currentUser.id !== 'HOSP-MUM-03' && currentUser.role !== 'admin') console.warn('Access Context Mismatch');
    setupNavigation();
    initModules();
    startRealTimeUpdates();
});

function initModules() {
    updateAnalytics();
    renderDocMgmt();
    setupSlotManager();
    renderBedMgmt('all');
    setupBedActions();
    setupEmergencyControl();
}

function startRealTimeUpdates() {
    setInterval(() => {
        const storedState = JSON.parse(localStorage.getItem(STORAGE_KEY));
        if (storedState) {
            hospitalState = storedState;
            updateAnalytics();
            if (document.querySelector('.nav-item[data-view="beds"]').classList.contains('active')) {
                const activeFilter = document.querySelector('.filter-btn.active')?.getAttribute('data-ward') || 'all';
                renderBedMgmt(activeFilter);
            }
        }
    }, 5000);
}

function setupNavigation() {
    const navItems = document.querySelectorAll('.nav-item');
    const views = document.querySelectorAll('.view');
    navItems.forEach(item => {
        item.addEventListener('click', () => {
            navItems.forEach(nav => nav.classList.remove('active'));
            item.classList.add('active');
            const targetViewId = item.getAttribute('data-view');
            views.forEach(view => { view.classList.remove('active'); view.classList.add('hidden'); });
            document.getElementById(targetViewId).classList.remove('hidden'); document.getElementById(targetViewId).classList.add('active');
            if (targetViewId === 'doctors') renderDocMgmt();
            if (targetViewId === 'beds') renderBedMgmt('all');
        });
    });
    document.getElementById('btn-logout').addEventListener('click', () => {
        localStorage.removeItem('nhm_current_user'); localStorage.removeItem('isLoggedIn'); window.location.href = 'login.html';
    });
}

function updateAnalytics() {
    let totalBeds = 0, occupiedBeds = 0;
    hospitalState.wards.forEach(w => { totalBeds += w.capacity; occupiedBeds += w.occupied; });
    const freeBeds = totalBeds - occupiedBeds, occupancyRate = totalBeds > 0 ? Math.round((occupiedBeds / totalBeds) * 100) : 0;
    const availDocs = hospitalState.doctors.filter(d => d.status === 'Available').length;
    const set = (id, val) => { const el = document.getElementById(id); if (el) el.textContent = val; };
    set('stat-occupancy-rate', occupancyRate + '%'); set('stat-avail-docs', availDocs + ' / ' + hospitalState.doctors.length);
    set('stat-free-beds', freeBeds + ' beds'); set('stat-emergency-status', hospitalState.emergencyMode ? '🚨 ACTIVE' : 'Normal');
    set('analytics-total-beds', totalBeds); set('analytics-occ-beds', occupiedBeds); set('analytics-avail-docs', availDocs); set('analytics-occ-rate', occupancyRate + '%');
    const banner = document.getElementById('emergency-banner'); if (banner) banner.style.display = hospitalState.emergencyMode ? 'block' : 'none';
    const odoc = document.getElementById('overview-doctor-table');
    if (odoc) {
        odoc.innerHTML = '';
        hospitalState.doctors.forEach(doc => {
            const c = doc.status === 'Available' ? '#16a34a' : doc.status === 'In Surgery' ? '#dc2626' : '#f59e0b';
            odoc.innerHTML += `<tr>
                <td><strong>${doc.name}</strong></td>
                <td>${doc.dept}</td>
                <td><span style="color:${c};font-weight:700">${doc.status}</span></td>
            </tr>`;
        });
    }
    const oward = document.getElementById('overview-ward-table');
    if (oward) {
        oward.innerHTML = '';
        hospitalState.wards.forEach(w => {
            oward.innerHTML += `<tr>
                <td><strong>${w.name}</strong></td>
                <td>${w.capacity}</td>
                <td style="color:#dc2626;font-weight:700">${w.occupied}</td>
                <td style="color:#16a34a;font-weight:700">${w.capacity - w.occupied}</td>
            </tr>`;
        });
    }
    const awd = document.getElementById('analytics-ward-breakdown');
    if (awd) { awd.innerHTML = ''; hospitalState.wards.forEach(w => { const p = w.capacity > 0 ? Math.round((w.occupied / w.capacity) * 100) : 0; awd.innerHTML += `<tr><td>${w.name}</td><td>${w.capacity}</td><td>${w.occupied}</td><td>${w.capacity - w.occupied}</td><td><strong>${p}%</strong></td></tr>`; }); }
    const adoc = document.getElementById('analytics-doc-table');
    if (adoc) { adoc.innerHTML = ''; hospitalState.doctors.forEach(doc => { adoc.innerHTML += `<tr><td>${doc.name}</td><td>${doc.dept}</td><td>${doc.maxSlots}</td><td>${doc.status}</td></tr>`; }); }
}

function renderDocMgmt() {
    const tbody = document.getElementById('doc-mgmt-table');
    tbody.innerHTML = '';
    hospitalState.doctors.forEach(doc => {
        const tr = document.createElement('tr');
        tr.innerHTML = `<td><strong>${doc.name}</strong><br><small>${doc.specs}</small></td><td>${doc.dept}</td><td>${doc.status}</td><td><button class="btn btn-sm btn-outline">Edit</button></td>`;
        tbody.appendChild(tr);
    });
}

function setupSlotManager() {
    const select = document.getElementById('slot-mgmt-doc-select');
    select.innerHTML = '<option disabled selected>Select Doctor</option>';
    hospitalState.doctors.forEach(doc => { const opt = document.createElement('option'); opt.value = doc.id; opt.textContent = doc.name; select.appendChild(opt); });
    select.addEventListener('change', (e) => renderAdminSlots(e.target.value));
}

function renderAdminSlots(docId) {
    const container = document.getElementById('admin-slot-grid');
    container.innerHTML = '';
    const booked = hospitalState.bookedSlots[docId] || [];
    const slots = ["10:00 AM", "11:00 AM", "12:00 PM", "04:00 PM", "05:00 PM"];
    slots.forEach(s => {
        const d = document.createElement('div'); d.className = `slot-badge ${booked.includes(s) ? 'booked' : 'available'}`; d.textContent = s; container.appendChild(d);
    });
    document.getElementById('slot-stats').textContent = `Total: ${slots.length} | Booked: ${booked.length}`;
}

function renderBedMgmt(filter) {
    const container = document.getElementById('adm-wards-container');
    container.innerHTML = '';
    let wards = (filter === 'all') ? hospitalState.wards : hospitalState.wards.filter(w => w.type === filter);

    wards.forEach(w => {
        const pct = Math.round((w.occupied / w.capacity) * 100);
        const card = document.createElement('div'); card.className = 'ward-card';
        card.innerHTML = `<div class="ward-header"><h3>${w.name}</h3><span>${w.type}</span></div><div class="ward-body">Occupied: ${w.occupied}/${w.capacity}</div>`;
        container.appendChild(card);
    });

    let free = 0; hospitalState.wards.forEach(w => free += (w.capacity - w.occupied));
    document.querySelector('#live-bed-counter h2').textContent = free;

    const select = document.getElementById('bed-mgmt-ward-select');
    select.innerHTML = '<option disabled selected>Select Ward</option>';
    hospitalState.wards.forEach(w => { const opt = document.createElement('option'); opt.value = w.id; opt.textContent = w.name; select.appendChild(opt); });
}

function setupBedActions() {
    document.getElementById('btn-adm-admit').addEventListener('click', () => {
        const id = document.getElementById('bed-mgmt-ward-select').value;
        const w = hospitalState.wards.find(x => x.id === id);
        if (w && w.occupied < w.capacity) { w.occupied++; saveState(); renderBedMgmt('all'); updateAnalytics(); alert('Admitted'); }
    });
    document.getElementById('btn-adm-discharge').addEventListener('click', () => {
        const id = document.getElementById('bed-mgmt-ward-select').value;
        const w = hospitalState.wards.find(x => x.id === id);
        if (w && w.occupied > 0) { w.occupied--; saveState(); renderBedMgmt('all'); updateAnalytics(); alert('Discharged'); }
    });
}

function setupEmergencyControl() {
    const toggle = document.getElementById('emergency-mode-toggle');
    toggle.checked = hospitalState.emergencyMode;
    toggle.addEventListener('change', (e) => {
        hospitalState.emergencyMode = e.target.checked; saveState(); updateAnalytics();
    });
}
