// pharmacy.js

let currentUser = JSON.parse(localStorage.getItem('nhm_current_user')) || { name: 'Patient', role: 'patient', id: 'guest' };
let cart = [];

document.addEventListener('DOMContentLoaded', () => {
    document.getElementById('current-user-name').textContent = currentUser.name;
    document.getElementById('current-user-role').textContent = currentUser.role === 'admin' ? 'Administrator' : 'Patient';
    document.getElementById('user-avatar').src = `https://ui-avatars.com/api/?name=${encodeURIComponent(currentUser.name)}&background=0D8ABC&color=fff`;

    setupPharmacy();
    loadOrderHistory();
});

// ============================================================
//  SAVES a completed order to the backend (db.json)
// ============================================================
async function saveOrder(paymentId, items, total) {
    try {
        const res = await fetch('http://localhost:3000/api/medicine-orders', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                userId: currentUser.id,
                userName: currentUser.name,
                paymentId: paymentId,
                items: items,
                total: total
            })
        });
        if (!res.ok) throw new Error('Failed to save order');
        return await res.json();
    } catch (err) {
        console.error('Order save error:', err);
        return null;
    }
}

// ============================================================
//  LOADS and RENDERS order history for the current user
// ============================================================
async function loadOrderHistory() {
    const container = document.getElementById('order-history-list');
    container.innerHTML = '<p style="color: var(--text-muted); text-align: center; padding: 1rem;">Loading history...</p>';

    try {
        const res = await fetch(`http://localhost:3000/api/medicine-orders/${encodeURIComponent(currentUser.id)}`);
        if (!res.ok) throw new Error('Failed to fetch history');

        const orders = await res.json();

        if (orders.length === 0) {
            container.innerHTML = '<p style="color: var(--text-muted); text-align: center; padding: 1rem;">No past orders found.</p>';
            return;
        }

        container.innerHTML = '';

        // Most recent first
        [...orders].reverse().forEach(order => {
            const date = new Date(order.date);
            const formattedDate = date.toLocaleDateString('en-IN', {
                day: '2-digit', month: 'short', year: 'numeric'
            });
            const formattedTime = date.toLocaleTimeString('en-IN', {
                hour: '2-digit', minute: '2-digit'
            });

            const itemsText = order.items.map(i => `${i.name} x${i.count}`).join(', ');

            const card = document.createElement('div');
            card.className = 'order-history-card';
            card.innerHTML = `
                <div class="order-history-header">
                    <div>
                        <span class="order-id">${order.orderId}</span>
                        <span class="order-date">${formattedDate} at ${formattedTime}</span>
                    </div>
                    <span class="order-total">₹${order.total}</span>
                </div>
                <div class="order-items-text">${itemsText}</div>
                <div class="order-payment-id">Payment ID: <code>${order.paymentId}</code></div>
            `;
            container.appendChild(card);
        });

    } catch (err) {
        container.innerHTML = '<p style="color: var(--danger-color); text-align: center; padding: 1rem;">Could not load history. Is the server running?</p>';
    }
}

// ============================================================
//  PHARMACY CART LOGIC
// ============================================================
function setupPharmacy() {
    const form = document.getElementById('pharmacy-form');
    const select = document.getElementById('medicine-select');
    const countInput = document.getElementById('medicine-count');
    const cartList = document.getElementById('cart-list');
    const cartTotalNode = document.getElementById('cart-total');
    const checkoutBtn = document.getElementById('btn-checkout');

    form.addEventListener('submit', (e) => {
        e.preventDefault();

        const medName = select.options[select.selectedIndex].text.split(' - ')[0];
        const medPrice = parseInt(select.options[select.selectedIndex].getAttribute('data-price'), 10);
        const count = parseInt(countInput.value, 10);

        if (!medName || isNaN(medPrice) || isNaN(count) || count < 1) {
            alert('Please select a valid medicine and quantity.');
            return;
        }

        const existingItem = cart.find(item => item.name === medName);
        if (existingItem) {
            existingItem.count += count;
        } else {
            cart.push({ name: medName, price: medPrice, count: count });
        }

        updateCartUI();
        form.reset();
        countInput.value = 1;
        showToast('Added to Cart', `${count}x ${medName} added successfully.`);
    });

    cartList.addEventListener('click', (e) => {
        if (e.target.closest('.btn-remove-item')) {
            const index = e.target.closest('.btn-remove-item').getAttribute('data-index');
            cart.splice(index, 1);
            updateCartUI();
        }
    });

    checkoutBtn.addEventListener('click', () => {
        if (cart.length === 0) return;

        const total = cart.reduce((acc, item) => acc + (item.price * item.count), 0);

        // ====================================================================
        //  RAZORPAY CONFIGURATION  —  FILL IN YOUR DETAILS BELOW
        // ====================================================================

        const RAZORPAY_KEY_ID = "rzp_test_S7j0HLsBua08hd";
        const BUSINESS_NAME = "NHM Hospital Pharmacy";
        const BUSINESS_LOGO_URL = "https://ui-avatars.com/api/?name=NHM&background=0D8ABC&color=fff";
        const PREFILL_EMAIL = "patient@nhm.gov.in";
        const PREFILL_CONTACT = "9999999999";
        const THEME_COLOR = "#0d8abc";

        // ====================================================================
        //  DO NOT EDIT BELOW THIS LINE
        // ====================================================================

        if (RAZORPAY_KEY_ID === "YOUR_RAZORPAY_KEY_ID") {
            alert("Razorpay Key not configured!\n\nOpen pharmacy.js and replace YOUR_RAZORPAY_KEY_ID with your actual Key ID.");
            return;
        }

        // Snapshot the cart before clearing it
        const orderSnapshot = cart.map(item => ({ ...item }));

        var options = {
            "key": RAZORPAY_KEY_ID,
            "amount": total * 100,
            "currency": "INR",
            "name": BUSINESS_NAME,
            "description": orderSnapshot.map(i => i.name + ' x' + i.count).join(', '),
            "image": BUSINESS_LOGO_URL,
            "handler": async function (response) {
                // ✅ Payment successful — save to history
                const saved = await saveOrder(response.razorpay_payment_id, orderSnapshot, total);

                if (saved) {
                    showToast('Payment Successful!', 'Order ID: ' + saved.orderId + ' | Payment ID: ' + response.razorpay_payment_id);
                } else {
                    showToast('Payment Done', 'Payment ID: ' + response.razorpay_payment_id + ' (History save failed — is the server running?)');
                }

                cart = [];
                updateCartUI();
                loadOrderHistory(); // Refresh history panel
            },
            "prefill": {
                "name": currentUser.name,
                "email": PREFILL_EMAIL,
                "contact": PREFILL_CONTACT
            },
            "notes": {
                "order_items": orderSnapshot.map(i => i.name + ' x' + i.count).join(', ')
            },
            "theme": {
                "color": THEME_COLOR
            },
            "modal": {
                "ondismiss": function () {
                    showToast('Payment Cancelled', 'You closed the payment window. Your cart is still intact.');
                }
            }
        };

        var rzp = new Razorpay(options);
        rzp.on('payment.failed', function (response) {
            alert("Payment Failed!\nReason: " + response.error.description);
        });
        rzp.open();
    });

    function updateCartUI() {
        cartList.innerHTML = '';
        let total = 0;

        if (cart.length === 0) {
            cartList.innerHTML = '<li class="placeholder-text" style="color: var(--text-muted);">Your cart is empty.</li>';
            checkoutBtn.disabled = true;
        } else {
            cart.forEach((item, index) => {
                const itemTotal = item.price * item.count;
                total += itemTotal;

                const li = document.createElement('li');
                li.style.cssText = 'display:flex; justify-content:space-between; align-items:center; padding:0.5rem 0; border-bottom:1px solid var(--border-color);';
                li.innerHTML =
                    '<div style="flex:1;">' +
                        '<span style="font-weight:500;">' + item.name + '</span>' +
                        '<div style="font-size:0.85rem;color:var(--text-muted);">\u20b9' + item.price + ' x ' + item.count + '</div>' +
                    '</div>' +
                    '<div style="font-weight:600;margin-right:1rem;">\u20b9' + itemTotal + '</div>' +
                    '<button type="button" class="btn-remove-item" data-index="' + index + '" style="background:none;border:none;color:var(--danger-color);cursor:pointer;padding:4px;">' +
                        '<i class="fa-solid fa-trash"></i>' +
                    '</button>';
                cartList.appendChild(li);
            });
            checkoutBtn.disabled = false;
        }

        cartTotalNode.textContent = '\u20b9' + total;
    }
}

// --- UTILS ---
let toastTimeout;
function showToast(title, message) {
    const toast = document.getElementById('toast');
    toast.querySelector('.toast-title').textContent = title;
    toast.querySelector('.toast-message').textContent = message;

    toast.classList.remove('hidden');
    void toast.offsetWidth;
    toast.classList.add('show');

    clearTimeout(toastTimeout);
    toastTimeout = setTimeout(() => {
        toast.classList.remove('show');
        setTimeout(() => toast.classList.add('hidden'), 300);
    }, 4000);
}

document.querySelector('.toast-close').addEventListener('click', () => {
    const toast = document.getElementById('toast');
    toast.classList.remove('show');
    setTimeout(() => toast.classList.add('hidden'), 300);
});
