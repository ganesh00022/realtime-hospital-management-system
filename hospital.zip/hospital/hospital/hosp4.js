// hosp4.js - Logic for Metro City Hospital
const defaultState = {
    doctors: [
        { id: 'd1', name: 'Dr. Farhan Akthar', dept: 'ENT', maxSlots: 6, specs: 'Sinus Specialist', status: 'Available' },
        { id: 'd2', name: 'Dr. Vidya Balan', dept: 'Urology', maxSlots: 5, specs: 'Kidney Specialist', status: 'Available' },
        { id: 'd3', name: 'Dr. Salman Khan', dept: 'Nephrology', maxSlots: 4, specs: 'Dialysis Lead', status: 'In Surgery' }
    ],
    wards: [
        { id: 'w1', name: 'Kidney Care Center', type: 'specialized', capacity: 20, occupied: 6 },
        { id: 'w2', name: 'General Ward A', type: 'general', capacity: 50, occupied: 30 },
        { id: 'w3', name: 'Dialysis Unit', type: 'specialized', capacity: 15, occupied: 12 }
    ],
    appointments: [], bookedSlots: {}, emergencyMode: false
};
const STORAGE_KEY = 'nhm_state_HOSP-MUM-04';
let hospitalState = JSON.parse(localStorage.getItem(STORAGE_KEY)) || defaultState;
let currentUser = JSON.parse(localStorage.getItem('nhm_current_user')) || { name: 'Admin', role: 'admin' };

function saveState() { localStorage.setItem(STORAGE_KEY, JSON.stringify(hospitalState)); }

document.addEventListener('DOMContentLoaded', () => {
    setupNavigation(); initModules(); startRealTimeUpdates();
});

function initModules() {
    updateAnalytics(); renderDocMgmt(); setupSlotManager(); renderBedMgmt('all'); setupBedActions(); setupEmergencyControl();
}

function startRealTimeUpdates() {
    setInterval(() => {
        const stored = JSON.parse(localStorage.getItem(STORAGE_KEY));
        if (stored) { hospitalState = stored; updateAnalytics(); if (document.querySelector('.view.active').id === 'beds') renderBedMgmt('all'); }
    }, 5000);
}

function setupNavigation() {
    document.querySelectorAll('.nav-item').forEach(item => {
        item.addEventListener('click', () => {
            document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
            item.classList.add('active');
            document.querySelectorAll('.view').forEach(v => { v.classList.remove('active'); v.classList.add('hidden'); });
            const tid = item.getAttribute('data-view');
            document.getElementById(tid).classList.remove('hidden'); document.getElementById(tid).classList.add('active');
            if (tid === 'doctors') renderDocMgmt(); if (tid === 'beds') renderBedMgmt('all');
        });
    });
    document.getElementById('btn-logout').addEventListener('click', () => { localStorage.removeItem('nhm_current_user'); window.location.href = 'login.html'; });
}

function updateAnalytics() {
    let totalBeds = 0, occupiedBeds = 0;
    hospitalState.wards.forEach(w => { totalBeds += w.capacity; occupiedBeds += w.occupied; });
    const freeBeds = totalBeds - occupiedBeds, occupancyRate = totalBeds > 0 ? Math.round((occupiedBeds / totalBeds) * 100) : 0;
    const availDocs = hospitalState.doctors.filter(d => d.status === 'Available').length;
    const set = (id, val) => { const el = document.getElementById(id); if (el) el.textContent = val; };
    set('stat-occupancy-rate', occupancyRate + '%'); set('stat-avail-docs', availDocs + ' / ' + hospitalState.doctors.length);
    set('stat-free-beds', freeBeds + ' beds'); set('stat-emergency-status', hospitalState.emergencyMode ? '🚨 ACTIVE' : 'Normal');
    set('analytics-total-beds', totalBeds); set('analytics-occ-beds', occupiedBeds); set('analytics-avail-docs', availDocs); set('analytics-occ-rate', occupancyRate + '%');
    const banner = document.getElementById('emergency-banner'); if (banner) banner.style.display = hospitalState.emergencyMode ? 'block' : 'none';
    const odoc = document.getElementById('overview-doctor-table');
    if (odoc) {
        odoc.innerHTML = '';
        hospitalState.doctors.forEach(doc => {
            const c = doc.status === 'Available' ? '#16a34a' : doc.status === 'In Surgery' ? '#dc2626' : '#f59e0b';
            odoc.innerHTML += `<tr>
                <td><strong>${doc.name}</strong></td>
                <td>${doc.dept}</td>
                <td><span style="color:${c};font-weight:700">${doc.status}</span></td>
            </tr>`;
        });
    }
    const oward = document.getElementById('overview-ward-table');
    if (oward) {
        oward.innerHTML = '';
        hospitalState.wards.forEach(w => {
            oward.innerHTML += `<tr>
                <td><strong>${w.name}</strong></td>
                <td>${w.capacity}</td>
                <td style="color:#dc2626;font-weight:700">${w.occupied}</td>
                <td style="color:#16a34a;font-weight:700">${w.capacity - w.occupied}</td>
            </tr>`;
        });
    }
    const awd = document.getElementById('analytics-ward-breakdown');
    if (awd) { awd.innerHTML = ''; hospitalState.wards.forEach(w => { const p = w.capacity > 0 ? Math.round((w.occupied / w.capacity) * 100) : 0; awd.innerHTML += `<tr><td>${w.name}</td><td>${w.capacity}</td><td>${w.occupied}</td><td>${w.capacity - w.occupied}</td><td><strong>${p}%</strong></td></tr>`; }); }
    const adoc = document.getElementById('analytics-doc-table');
    if (adoc) { adoc.innerHTML = ''; hospitalState.doctors.forEach(doc => { adoc.innerHTML += `<tr><td>${doc.name}</td><td>${doc.dept}</td><td>${doc.maxSlots}</td><td>${doc.status}</td></tr>`; }); }
}

function renderDocMgmt() {
    const b = document.getElementById('doc-mgmt-table'); b.innerHTML = '';
    hospitalState.doctors.forEach(d => {
        const r = document.createElement('tr'); r.innerHTML = `<td>${d.name}<br><small>${d.specs}</small></td><td>${d.dept}</td><td>${d.status}</td><td><button class="btn btn-sm">Edit</button></td>`;
        b.appendChild(r);
    });
}

function setupSlotManager() {
    const s = document.getElementById('slot-mgmt-doc-select'); s.innerHTML = '<option>Select</option>';
    hospitalState.doctors.forEach(d => { const o = document.createElement('option'); o.value = d.id; o.textContent = d.name; s.appendChild(o) });
    s.addEventListener('change', e => renderSlots(e.target.value));
}
function renderSlots(id) {
    const c = document.getElementById('admin-slot-grid'); c.innerHTML = '';
    const booked = hospitalState.bookedSlots[id] || [];
    ["9AM", "10AM", "11AM", "2PM"].forEach(sl => {
        const d = document.createElement('div'); d.className = `slot-badge ${booked.includes(sl) ? 'booked' : 'available'}`; d.textContent = sl; c.appendChild(d);
    });
}
function renderBedMgmt(f) {
    const c = document.getElementById('adm-wards-container'); c.innerHTML = '';
    const ws = f === 'all' ? hospitalState.wards : hospitalState.wards.filter(w => w.type === f);
    ws.forEach(w => {
        const d = document.createElement('div'); d.className = 'ward-card';
        d.innerHTML = `<div class="ward-header"><h3>${w.name}</h3></div><div>Occupied: ${w.occupied}/${w.capacity}</div>`;
        c.appendChild(d);
    });
    const s = document.getElementById('bed-mgmt-ward-select'); s.innerHTML = '<option>Select</option>';
    hospitalState.wards.forEach(w => { const o = document.createElement('option'); o.value = w.id; o.textContent = w.name; s.appendChild(o) });
    let free = 0; hospitalState.wards.forEach(w => free += (w.capacity - w.occupied));
    document.querySelector('#live-bed-counter h2').textContent = free;
}
function setupBedActions() {
    document.getElementById('btn-adm-admit').addEventListener('click', () => {
        const id = document.getElementById('bed-mgmt-ward-select').value;
        const w = hospitalState.wards.find(x => x.id === id);
        if (w && w.occupied < w.capacity) { w.occupied++; saveState(); renderBedMgmt('all'); alert('Admitted') }
    });
    document.getElementById('btn-adm-discharge').addEventListener('click', () => {
        const id = document.getElementById('bed-mgmt-ward-select').value;
        const w = hospitalState.wards.find(x => x.id === id);
        if (w && w.occupied > 0) { w.occupied--; saveState(); renderBedMgmt('all'); alert('Discharged') }
    });
}
function setupEmergencyControl() {
    const t = document.getElementById('emergency-mode-toggle'); t.checked = hospitalState.emergencyMode;
    t.addEventListener('change', e => { hospitalState.emergencyMode = e.target.checked; saveState(); updateAnalytics(); });
}
