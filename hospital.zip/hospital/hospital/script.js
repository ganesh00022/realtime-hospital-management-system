'use strict';

/* ── Availability indicator (9 AM – 8 PM IST) ── */
(function () {
    const now = new Date();
    const ist = new Date(now.getTime() + (5.5 * 3600000) + now.getTimezoneOffset() * 60000);
    const h = ist.getHours();
    const on = h >= 9 && h < 20;
    document.getElementById('dot').classList.toggle('off', !on);
    document.getElementById('availMsg').textContent = on
        ? 'Support team is online now'
        : 'Currently offline — opens 9 AM IST';
})();

/* ── Character counter ── */
document.getElementById('message').addEventListener('input', function () {
    const el = document.getElementById('cc');
    el.textContent = this.value.length;
    el.style.color = this.value.length > 450 ? '#f87171' : '';
});

/* ── Validation ── */
function ok(id, eid) {
    document.getElementById(id).classList.remove('err-active');
    document.getElementById(eid).textContent = '';
}
function fail(id, eid, msg) {
    document.getElementById(id).classList.add('err-active');
    document.getElementById(eid).textContent = msg;
    return false;
}

function validate(d) {
    let v = true;
    if (!d.fullName.trim() || d.fullName.trim().length < 2)
        v = fail('fg-name', 'e-name', 'Enter a valid full name.') && false;
    else ok('fg-name', 'e-name');

    const eRe = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!eRe.test(d.email.trim()))
        v = fail('fg-email', 'e-email', 'Enter a valid email address.') && false;
    else ok('fg-email', 'e-email');

    const pRe = /^[+\d][\d\s\-(). ]{6,17}$/;
    if (!pRe.test(d.phone.trim()))
        v = fail('fg-phone', 'e-phone', 'Enter a valid phone number.') && false;
    else ok('fg-phone', 'e-phone');

    if (!d.hospital)
        v = fail('fg-hospital', 'e-hospital', 'Please select a hospital.') && false;
    else ok('fg-hospital', 'e-hospital');

    if (!d.subject)
        v = fail('fg-subject', 'e-subject', 'Please select a subject.') && false;
    else ok('fg-subject', 'e-subject');

    if (!d.message.trim() || d.message.trim().length < 5)
        v = fail('fg-message', 'e-message', 'Please enter a message (min 5 chars).') && false;
    else ok('fg-message', 'e-message');

    return v;
}

/* ── Save to feedback.json via backend (localStorage as fallback) ── */
const STORE = 'uhp_submissions';

function saveToLocalStorage(entry) {
    try {
        const all = JSON.parse(localStorage.getItem(STORE)) || [];
        all.push(entry);
        localStorage.setItem(STORE, JSON.stringify(all, null, 2));
    } catch (e) { /* ignore */ }
}

async function saveEntry(entry) {
    /* 1. Always persist locally as a safety net */
    saveToLocalStorage(entry);

    /* 2. Send to backend → written to contacts.json on disk */
    try {
        const res = await fetch('http://localhost:3000/api/contacts', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(entry)
        });
        if (!res.ok) throw new Error(`Server responded ${res.status}`);
        const json = await res.json();
        console.log('✅ Saved to contacts.json, id:', json.id);
    } catch (err) {
        console.warn('⚠️  Server unavailable – data kept in localStorage only.', err.message);
    }
}

/* ── Form submit ── */
const form = document.getElementById('contactForm');
const sendBtn = document.getElementById('sendBtn');
const bt = sendBtn.querySelector('.bt');
const bl = sendBtn.querySelector('.bl');
const success = document.getElementById('success');

form.addEventListener('submit', async function (e) {
    e.preventDefault();

    const data = {
        fullName: document.getElementById('fullName').value.trim(),
        email: document.getElementById('email').value.trim(),
        phone: document.getElementById('phone').value.trim(),
        hospital: document.getElementById('hospital').value,
        subject: document.getElementById('subject').value,
        message: document.getElementById('message').value.trim()
    };

    if (!validate(data)) return;

    /* show loader */
    sendBtn.disabled = true;
    bt.style.display = 'none';
    bl.style.display = 'flex';

    const entry = { id: Date.now(), submittedAt: new Date().toISOString(), ...data };
    await saveEntry(entry);   // POST to server → feedback.json

    /* show success */
    sendBtn.disabled = false;
    bt.style.display = 'flex';
    bl.style.display = 'none';
    form.style.display = 'none';
    success.style.display = 'flex';
    form.reset();
    document.getElementById('cc').textContent = '0';
});

/* ── Send Another ── */
document.getElementById('again').addEventListener('click', () => {
    success.style.display = 'none';
    form.style.display = 'block';
});
