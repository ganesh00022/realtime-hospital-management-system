const http = require('http');
const fs = require('fs');
const path = require('path');

const PORT = 3000;
const DB_FILE = path.join(__dirname, 'db.json');
const CONTACTS_FILE = path.join(__dirname, 'contacts.json');

// Initialize DB if not exists
if (!fs.existsSync(DB_FILE)) {
    fs.writeFileSync(DB_FILE, JSON.stringify({ users: [] }, null, 2));
}

const server = http.createServer((req, res) => {
    // Add CORS headers
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'OPTIONS, GET, POST');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

    if (req.method === 'OPTIONS') {
        res.writeHead(204);
        res.end();
        return;
    }

    if (req.url === '/api/register' && req.method === 'POST') {
        let body = '';
        req.on('data', chunk => body += chunk.toString());
        req.on('end', () => {
            const { id, name, pass, role } = JSON.parse(body);
            const db = JSON.parse(fs.readFileSync(DB_FILE, 'utf8'));

            if (db.users.find(u => u.id === id)) {
                res.writeHead(400, { 'Content-Type': 'application/json' });
                res.end(JSON.stringify({ error: 'User ID already exists' }));
                return;
            }

            const newUser = { id, name, pass, role: role || 'patient' };
            db.users.push(newUser);
            fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2));

            res.writeHead(201, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify(newUser));
        });
    } else if (req.url === '/api/login' && req.method === 'POST') {
        let body = '';
        req.on('data', chunk => body += chunk.toString());
        req.on('end', () => {
            const { id, pass, role } = JSON.parse(body);
            const db = JSON.parse(fs.readFileSync(DB_FILE, 'utf8'));

            const user = db.users.find(u => u.id === id && u.pass === pass && u.role === role);
            if (user) {
                res.writeHead(200, { 'Content-Type': 'application/json' });
                res.end(JSON.stringify(user));
            } else {
                res.writeHead(401, { 'Content-Type': 'application/json' });
                res.end(JSON.stringify({ error: 'Invalid credentials' }));
            }
        });
    } else if (req.url === '/api/wards' && req.method === 'GET') {
        const db = JSON.parse(fs.readFileSync(DB_FILE, 'utf8'));
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify(db.wards));
    } else if (req.url === '/api/wards/update' && req.method === 'POST') {
        let body = '';
        req.on('data', chunk => body += chunk.toString());
        req.on('end', () => {
            const { wardId, action } = JSON.parse(body); // action: 'admit' or 'discharge'
            const db = JSON.parse(fs.readFileSync(DB_FILE, 'utf8'));
            const ward = db.wards.find(w => w.id === wardId);

            if (!ward) {
                res.writeHead(404, { 'Content-Type': 'application/json' });
                res.end(JSON.stringify({ error: 'Ward not found' }));
                return;
            }

            if (action === 'admit' && ward.occupied < ward.capacity) {
                ward.occupied++;
            } else if (action === 'discharge' && ward.occupied > 0) {
                ward.occupied--;
            } else {
                res.writeHead(400, { 'Content-Type': 'application/json' });
                res.end(JSON.stringify({ error: 'Invalid action or capacity reached' }));
                return;
            }

            fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2));
            res.writeHead(200, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify(db.wards));
        });
    } else if (req.url === '/api/medicine-orders' && req.method === 'POST') {
        // Save a new medicine order
        let body = '';
        req.on('data', chunk => body += chunk.toString());
        req.on('end', () => {
            const { userId, userName, paymentId, items, total } = JSON.parse(body);
            const db = JSON.parse(fs.readFileSync(DB_FILE, 'utf8'));

            if (!db.orders) db.orders = [];

            const order = {
                orderId: 'ORD-' + Date.now(),
                userId,
                userName,
                paymentId,
                items,
                total,
                date: new Date().toISOString()
            };

            db.orders.push(order);
            fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2));

            res.writeHead(201, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify(order));
        });
    } else if (req.url.startsWith('/api/medicine-orders/') && req.method === 'GET') {
        // Get order history for a specific user
        const userId = decodeURIComponent(req.url.split('/api/medicine-orders/')[1]);
        const db = JSON.parse(fs.readFileSync(DB_FILE, 'utf8'));
        const userOrders = (db.orders || []).filter(o => o.userId === userId);

        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify(userOrders));
    } else if (req.url === '/api/contacts' && req.method === 'POST') {
        // Save a contact form submission to contacts.json
        let body = '';
        req.on('data', chunk => body += chunk.toString());
        req.on('end', () => {
            const entry = JSON.parse(body);
            let contacts = [];
            try {
                contacts = JSON.parse(fs.readFileSync(CONTACTS_FILE, 'utf8'));
            } catch (e) { contacts = []; }

            contacts.push(entry);
            fs.writeFileSync(CONTACTS_FILE, JSON.stringify(contacts, null, 2));

            res.writeHead(201, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify(entry));
        });
    } else if (req.url === '/api/contacts' && req.method === 'GET') {
        // Get all contact submissions
        let contacts = [];
        try {
            contacts = JSON.parse(fs.readFileSync(CONTACTS_FILE, 'utf8'));
        } catch (e) { contacts = []; }

        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify(contacts));
    } else {
        res.writeHead(404);
        res.end();
    }
});

server.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});
